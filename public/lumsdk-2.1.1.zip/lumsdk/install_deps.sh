#!/bin/bash

# install ros
sudo sh -c 'echo "deb http://packages.ros.org/ros/ubuntu $(lsb_release -sc) main" > /etc/apt/sources.list.d/ros-latest.list'
sudo apt-key adv --keyserver hkp://ha.pool.sks-keyservers.net:80 --recv-key 0xB01FA116
sudo apt-get update
sudo apt-get install -y ros-kinetic-desktop-full
echo "source /opt/ros/kinetic/setup.bash" >> ~/.bashrc
sudo apt-get install -y python-rosinstall

# setup network interface
sudo bash -c 'cat <<EOF >> /etc/network/interfaces
auto enp0s31f6
iface enp0s31f6 inet static
    address 10.42.0.1
    netmask 255.255.255.0
    mtu 9000
EOF'

sudo /etc/init.d/networking stop
sudo /etc/init.d/networking start
