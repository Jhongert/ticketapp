The LumSDK demonstrates how to communicate with the Luminar Model G series firmware.

Default Settings
================
The sensor by default has the following IP address, configurable by sending a “Set IP Address” packet: <b>10.42.0.37</b>

The sensor has the following UDP port, which is unchangeable: <b>5117</b>

Multicast is not supported.

The LIDAR sensor currently contains 2 eyes, arbitrarily designated as a “Green” and “Blue” eye. The field of view of the Green eye in the frame of the sensor is to the left, the Blue to the right. Whenever a field named eye is in a packet structure below, a value of 0 corresponds to the green eye and a value of 1 corresponds to the blue eye. The blue eye scans from bottom to top while the green eye scans from top to bottom. When stitching the two eyes together to form a 2000 point 120 degree x-axis field of view, the blue frame (right side) must be flipped vertically to compensate for this action.

Basic Packet Structure
======================
The communication between the Luminar sensor and client machine occurs over UDP.
UDP payloads contain a common 12 byte header at the start of the UDP payload:

| Byte | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9| 10|
|-|-|-|-|-|-|-|-|-|||
|| ed | fe | f3 | a1 | ef | be | 34 | 12 | Type Low | Type Hi (0)|

```c
#define LUM_MAGIC_NUMBER \
  (0x1234L << 48 | 0xbeefL << 32 | 0xa1f3L << 16 | 0xfeedL)

struct lum_packet_header {
  uint64_t magic_number_long; // must equal LUM_MAGIC_NUMBER
  uint32_t packet_type;
};
```

The first 8 bytes of the datagram are a unique identifier to signify that this is a Luminar packet. This is a check to minimize the chances of another packet being misinterpreted, to compensate for the connectionless nature of UDP. Any packet whose first 8 bytes are not equal to LUM_MAGIC_NUMBER are ignored.

The next 4 bytes are for the packet type. The packet type defines how to interpret the remaining bytes of the payload. See the table under header Packet Types to see the appropriate values for various packet types.

Packet Types
============
There are several UDP packet types in the current version of the Luminar interface. Each has a defined interaction mode; importantly, they do not all receive an acknowledgment packet.

Notices:
Lidar and server are used interchangeably in this document.
The document uses C structs to document the packet formats. Some structs end in a char array member of size 1 (e.g., “char payload[1]”). This denotes a flexible array, since the payload of the packet past that point is not a fixed size. We use a 1-sized array rather the more conventional 0-sized array because the latter is not C++-compliant.

In addition to this document, sample source code is provided demonstrating usage of these packets in simple C and C++ programs, including a visualizer using Robot Operating System’s rviz application.

The following table documents the appropriate values for the packet_type field:

| Packet Type           | Value in packet_type field of header |
|-----------------------|:------------------------------------:|
| Set IP Address Packet |            5                         |
| Timestamp Packet      |            6                         |
| TLV Packet            |            7                         |
| Heartbeat Packet      |            8                         |

IP Address Packet
=================

The Set IP Address Packet is sent by the client to the server only.

- The IP Address Packet is a non-responsive packet type.
- The sensor will immediately try to change IP address if the packet is valid.
- No acknowledgement packet is sent, since receiving packets from the new address should provide acknowledgement.
- The client should then communicate with the new IP address to verify the IP address was changed.

- The client must know the server’s initial IP address in order to set its IP address.
- Because the sensor always boots up with 10.42.0.37 as its default IP address, a packet can be directly sent to the default IP address.
- Setting the IP address via UDP broadcast packets is not supported at this time.
- This can be maneuvered around via Linux’s virtual network interfaces, in case your network is not a 10.x.x.x subnet.

```c
struct address_packet_struct
{
  char     packetType;
  char     reserved[3];
  uint32_t newIPAddress;
};
```

Timestamp Packet
================

The Timestamp Packets are sent by both the client and the LIDAR.

- The timestamp packet is to allow the client to know the difference between the sensor’s clock and the client’s clock.
- When a client sends a Timestamp Pack packet to the LIDAR, the value of the sent timestamp field is ignored.
- The response packet has the same sequence number as the request packet, but with the timestamp field set to a 32-bit timestamp since bootup when the packet entered the server’s receive queue.
- Note that since this value is a 32 bit unsigned integer, it will reset to zero about every 71 minutes.
- The purpose of the sequence number is to account for possible reordering of UDP packets.

 ```c
struct timestamp_packet_struct
{
  char     packetType;
  char     reserved1[3];
  uint32_t sequenceNum;
  uint32_t timeStamp; // In microseconds
};
```

TLV Packets
===========
TLV's are the primary method for status and command communication with the sensor.
The client uses this to send command packets to the sensor via the flexible array payload field, while the sensor uses it to communicate
debug output.

The payload of a UDP packet containing one or more TLV commands.
TLV stands for Type-Length-Vector, a general format where Vector is
the payload, Type is an identifier indicating how to interpret the
payload, and length is how large the payload is.

LUM_TLV_PACKET::tlvs contains an array of LUM_TLV objects, each of
which represents one TLV command. The reason that it is not typed
as a LUM_TLV array is because LUM_TLV is a flexible struct (it
doesn't have a fixed size).

Every LUM_TLV_PACKET received by the lidar will cause another
LUM_TLV_PACKET to be returned back to the sender, containing the
same LUM_TLV_PACKET::sequence number, for bookkeeping purposes.

Documentation of possible TLV's are contained in `include/fpga-firmware/sw/lum_tlv_eth_protocol.h`.

Heartbeat Packet
================

The heartbeat packet serves two primary purposes.

 - The first is to set the destination IP address and UDP port where the sensor will send LIDAR data packets.
 - The second is for safety - if a heartbeat packet is not received for a period of 3 seconds, the Luminar LIDAR will shut off the laser. This is primarily to provide a safe shutdown in the event of malfunction.

It is a good idea to send a heartbeat packet several times a second to ensure the timer is not tripped.
This packet does not get an acknowledgement packet, but will result in LIDAR data packets being sent
to the sender of the packet if successfully received.

```c
struct packet_acquire_enable_struct
{
  char    packet_type; // LUM_MULTI_DISTANCE_PACKET_TYPE
  char    reserved[3];
};
```

Multi-return Packet Format
==========================

LIDAR data is sent to the client in groups of points; there are 1000 points in a line.
Each line is transmitted as a group of UDP packets, the lum_group_header contains the
information necessary to identify the position of returns within a frame of data.
The lum_group_packet contains a lum_group_header and a payload, either angle or range data.

Angle payloads are transmitted in groups of (334, 334, 332) samples for the rising edges of the blue and green eyes.
Angle are transmitted 16 bit signed fixed-point values which must be converted to degrees or radians.
Within the angle packet header, the values of line, num_samples, and first_sample_index allow you to index
an angle value within a frame.

Ranges are transmitted as 32 bit signed integers. Along with the line and num_samples values from the header,
some bits of the 32 allow you to index the range data within a frame. The multi-return packet format is documented below.
Note: the return index is not given, to determine the index of a return within the total number of requested returns,
you must count up from 0th return, 1st, ...

Multi-return packet format.
Data values for multi-return data are formatted as follows:
- b31-12  == Range time value
- b11     == 0
- b10     == Rising flag
- B9-0    == X position

Data values immediately follow the header (lum_group_header).
There may be multiple returns for one pixel.
Multiple X return pixels will never cross a packet boundary.
All samples in a packet are contained on a single line.

```c
typedef struct
{
  uint8_t  tag;                // 2=angle data, 3=range distance data
  uint8_t  eye;                // 0 for green rise, 1 for blue rise, 2 for green drop, 3 for blue drop
  uint16_t line;               // horizontal scan line # for first sample
  uint16_t num_samples;        // number of samples
  uint16_t first_sample_index; // index of first sample (angle data only)
  uint32_t first_timestamp_us; // Timestamp of first angle sample in microseconds since bootup (not for range data)
} lum_group_header;
```

Calibration Methods
===================
This section outlines the basic calibration values needed for each sensor.

The sensor consists of 3 main components - a laser timing system, an azimuth angle galvanometer, and an elevation angle galvanometer. Each of these has calibration values that need to be set to produce correct 3d points.

The laser timing system gives timing measurements. An offset value is automatically applied to the time measurement values to calibrate out optical and electrical path delays.  An additional constant may be added to the TOF value to further compensate for system to system variations. Future implementations will employ deeper auto-calibration techniques.

The azimuth and elevation systems both have true zero positions, and angle widths. For elevation, this is parameterized in terms of a minimum and maximum angle. These need to be calibrated for each eye. Typical values are as follows:
- Highest elevation angle: 3 degrees
- Lowest elevation angle: -17 degrees
- Azimuth angle width: 60 degrees
- Azimuth angle center: 0 degrees

Along with the sample code, a sample calibration file is provided in a yaml format. These are loaded into a parameter server on software startup. `lumsdk_node.cpp` demonstrates how to use the calibration parameters to undiscretize and correct the raw data, in the process of transforming raw data into point clouds. Calibration is currently implemented as post-processing in software; it therefore does not affect raw data coming from the FPGA. Users are therefore not bound to implement our set of calibration parameters, and can choose a different set to better fit their needs.

Key Files
=========
- `include/fpga-firmware/sw/lum_eth_protocol.h`: Documentation of packet format for raw data, addresses, timestamps
- `include/fpga-firmware/sw/lum_tlv_eth_protocol.h`:  Documentation of packet format for TLV's
- `include/conversions.hpp` and `src/conversions.cpp`: Demonstrates how to undiscretize the raw data
- `include/fpga_client3.hpp` and `src/fpga_client3.cpp`: Demonstrates how to send heartbeat packets, and parse raw data packets
- `include/tlv/*` and `src/tlv*`: Demonstrates how to send/receive TLV packets. Sample functions for generating yscan distributions.
- `lumsdk_node.cpp`: Sample ROS Node that produces point clouds from the raw data and sends TLV's for sample commands

The lumsdk_node provides a sample terminal for commanding the sensor.

<b>Command Type						                     Example Payload</b>
1. Laser state
  - 1.1 ON                                     "u"
  - 1.2 OFF                                    "d"
2. Laser Power
  - 2.1 0-100 value		                         "50p"
3. Threshold Value
  - 3.1 Typical values between 0-100
    - 3.1.1 Green Eye					                 "17g"
    - 3.1.2 Blue Eye				                   "17b"
4. Uniform Y Scan
  - 5.1 <fov> Centered on horizon              "15y"
5. FPGA Holdoff delay
  - 6.1 Typical values between 150-250, intervals of 10 "200h"
6. Galvo/ADC Offset Value
  - 6.1 Typical values between 0-25
    - 6.1.1 Green Eye					                 "10B"
    - 6.1.2 Blue Eye				                   "10G"

<b>Note!</b> It can often take several seconds for the laser to come fully up.

Prerequisites
=============
- Robot Operating System (for visualization)
- A network interface on a subnet containing IPv4 address 10.42.0.37
- Curl to download sensor firmware

Initial Setup
=============
- <b>Note!</b> this is already done for you on delivery of a visualization computer.
- <b>Note!</b> If running on a system not provided by Luminar, you may need to replace enp0s31f6 in install_deps.sh with the name of your Ethernet network interface. This can be found by running ifconfig.
- This script installs prerequisites and sets up the network interface.

```sh
cd <path-to-lumsdk-dir>
./install_deps.sh
 ```

Build SDK
=========
- <b>Note!</b> this is already done for you on delivery of a visualization computer.

```sh
cd <path-to-lumsdk-dir>
catkin_make
 ```

Read Documentation
==================
- Open docs/html/index.html to view documentation.

Run LuminView
=============
- LuminView is a custom point cloud visualization tool which provides improved image quality over other tools such as rviz.  It also features angle smoothing which reduces noise in the point cloud.
- LuminView provides a return index selector and rising/falling edge toggle button, which allows for quick navigation between viewing different sets of returns.
- In LuminView, rotating the camera is done by left clicking and dragging in the direction of desired rotation.  The arrow keys are used to zoom (no modifier key), pan (shift pressed down), or orbit the camera (ctrl pressed down) in a particular direction.

```sh
cd <path-to-lumsdk-dir>
source devel/setup.bash
roslaunch luminar_point_cloud luminview.launch
```

Run Standard Visualizer (rviz)
==============================

```sh
cd <path-to-lumsdk-dir>
source devel/setup.bash
roslaunch luminar_point_cloud release.launch
```

Update Sensor Firmware
======================

In the event that updates to sensor firmware become available, we are distributing an executable to flash new firmware onto your device. Our flashing script will download the latest firmware from our firmware server, and program your device over Ethernet.

- This tool, named 'lumsdk_flash', can be used to upload new firmware onto the Luminar Model G.
- The tool is found in the tools directory inside of the lumsdk directory.
- New firmware can be downloaded via the Luminar web server.
- To run newly flashed firmware on the FPGA, power cycle the system.

```sh
# First, make sure communication is established with the sensor.
ping 10.42.0.37

cd <path-to-lumsdk-dir>/tools
./flash
```
