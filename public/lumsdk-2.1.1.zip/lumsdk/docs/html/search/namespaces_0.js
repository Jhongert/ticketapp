var searchData=
[
  ['lum',['lum',['../namespacelum.html',1,'']]]
];
