var searchData=
[
  ['hdr',['hdr',['../structlum__group__packet.html#ac295e6d9d24e7d4c32c99e3f72638964',1,'lum_group_packet']]],
  ['holdoff',['holdoff',['../structlum__tlv__holdoff__payload__struct.html#a739883e4bea71975c4a9941bb68b4f7e',1,'lum_tlv_holdoff_payload_struct']]],
  ['horizon_5fangle_5fdegrees',['HORIZON_ANGLE_DEGREES',['../namespacelum.html#af479fb66a39c8d22bf6fc2f08ac45052',1,'lum']]]
];
