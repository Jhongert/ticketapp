var searchData=
[
  ['raw_5fangles_5ft',['raw_angles_t',['../namespacelum.html#ac6b513574d55e6a3e6399116ef78e646',1,'lum']]],
  ['raw_5freturns_5ft',['raw_returns_t',['../namespacelum.html#a5bb0b0f06f73f5a7ce83ed9b708b3db1',1,'lum']]],
  ['rc',['rc',['../structlum__illegal__request__payload__struct.html#a3fe3d1ea4a70cca765d8522f9110bbbf',1,'lum_illegal_request_payload_struct']]],
  ['readme_2emd',['README.md',['../README_8md.html',1,'']]],
  ['real_5fdistance_5fpacket_5ftype',['REAL_DISTANCE_PACKET_TYPE',['../lum__eth__protocol_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba83bce7b5a7e58bce7b3e34462f1036c9',1,'lum_eth_protocol.h']]],
  ['real_5ftest_5fpacket_5ftype',['REAL_TEST_PACKET_TYPE',['../lum__eth__protocol_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba285b2f7fa9fce8b4c7224a3a702f0645',1,'lum_eth_protocol.h']]],
  ['request_5flen',['request_len',['../structlum__illegal__request__payload__struct.html#a0649f847b07224f72a2d186e0f9e460a',1,'lum_illegal_request_payload_struct']]],
  ['request_5ftype',['request_type',['../structlum__illegal__request__payload__struct.html#a1dbffad1830dd86a4ec3d50669f10e84',1,'lum_illegal_request_payload_struct']]],
  ['reserved',['reserved',['../structpacket__acquire__enable__struct.html#aeb7d083d74b08bfffd98a35f0d7d6672',1,'packet_acquire_enable_struct::reserved()'],['../structpacket__acquire__real__test__struct.html#ae45276ee6eb310eb648441ebac65763d',1,'packet_acquire_real_test_struct::reserved()'],['../structpacket__acquire__stop__struct.html#a06e779ff47a1e548282a3b837f4e1a59',1,'packet_acquire_stop_struct::reserved()'],['../structaddress__packet__struct.html#ab8a4e70ae27bb7c1804c89b1d220ec18',1,'address_packet_struct::reserved()'],['../structyscan__packet__struct.html#a888bc418b341ea0c45277cb177d526fb',1,'yscan_packet_struct::reserved()'],['../structlum__address__packet__struct.html#a9b5e7278e09cc78dc04de269d98c8e08',1,'lum_address_packet_struct::reserved()']]],
  ['reserved0',['reserved0',['../structlum__tlv__threshold__payload__struct.html#ab6c8ea8bd366f0c622a4e44cd8ed26ca',1,'lum_tlv_threshold_payload_struct::reserved0()'],['../structlum__tlv__sensor__number__returns__payload__struct.html#a70d40a914e84e0bc71aee90ce58f9abc',1,'lum_tlv_sensor_number_returns_payload_struct::reserved0()'],['../structlum__heartbeat__packet.html#a3366585ad1e23a97d4d08fa1d69716c0',1,'lum_heartbeat_packet::reserved0()'],['../structlum__timestamp__packet.html#a56425086b7eeb2f505cb321e72f49c49',1,'lum_timestamp_packet::reserved0()']]],
  ['reserved1',['reserved1',['../structtimestamp__packet__struct.html#aad4035df8400d7e91be6718a08c882ac',1,'timestamp_packet_struct::reserved1()'],['../unionlum__tlv__laser__state__payload__struct.html#a15c1352581d0b10d9872e2d8c5dd9441',1,'lum_tlv_laser_state_payload_struct::reserved1()']]],
  ['rising',['Rising',['../namespacelum.html#a5cf4cfe8695bfc994c73d87f2b0b26cea4475404a8e17049853e83d014a833ca1',1,'lum']]],
  ['run',['run',['../classlum_1_1TLVIO.html#af5ea4513e83608cf5cb95ac81078d724',1,'lum::TLVIO']]]
];
