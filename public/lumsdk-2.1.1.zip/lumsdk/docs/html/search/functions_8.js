var searchData=
[
  ['num_5freturns',['num_returns',['../classlum_1_1FpgaClient3.html#ac78ee51811c25793196d03bde566a863',1,'lum::FpgaClient3']]]
];
