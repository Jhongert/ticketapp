var searchData=
[
  ['y',['y',['../structlum_1_1PointXYZ.html#a584f470fe4655317b68648213864602c',1,'lum::PointXYZ']]],
  ['yscan_5fpositions',['yscan_positions',['../structyscan__packet__struct.html#a4e7b8a5aa02a59f3bbc9f5d0314e17be',1,'yscan_packet_struct::yscan_positions()'],['../structyscan2__packet__struct.html#a4906ae8e5edf2b4deaef657ec74de5e3',1,'yscan2_packet_struct::yscan_positions()']]]
];
