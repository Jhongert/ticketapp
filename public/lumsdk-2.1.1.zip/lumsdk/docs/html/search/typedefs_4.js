var searchData=
[
  ['raw_5fangles_5ft',['raw_angles_t',['../namespacelum.html#ac6b513574d55e6a3e6399116ef78e646',1,'lum']]],
  ['raw_5freturns_5ft',['raw_returns_t',['../namespacelum.html#a5bb0b0f06f73f5a7ce83ed9b708b3db1',1,'lum']]]
];
