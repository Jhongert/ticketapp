var searchData=
[
  ['use_5flum_5frev_5f0_5f1_5fformat',['USE_LUM_REV_0_1_FORMAT',['../lum__eth__protocol_8h.html#af45518ea69757300148de1080bba44a5',1,'lum_eth_protocol.h']]]
];
