var searchData=
[
  ['new_5fip_5faddress',['new_ip_address',['../structlum__address__packet__struct.html#a5fbba48d56ca233a26b2fd50ef6453f0',1,'lum_address_packet_struct']]],
  ['newipaddress',['newIPAddress',['../structaddress__packet__struct.html#a758c5afc644141132b9186719ca23f2e',1,'address_packet_struct']]],
  ['num_5fedges_5fper_5freturn',['NUM_EDGES_PER_RETURN',['../classlum_1_1FpgaClient3.html#a36ccc541b5e7af0fb511f79a798e394b',1,'lum::FpgaClient3']]],
  ['num_5fsamples',['num_samples',['../structlum__group__header.html#a557c5262b0dd0474382d603cec965897',1,'lum_group_header']]]
];
