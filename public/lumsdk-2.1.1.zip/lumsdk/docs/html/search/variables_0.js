var searchData=
[
  ['adcphaseoffset',['adcPhaseOffset',['../structlum__tlv__adc__phase__offset__payload__struct.html#a9c4b3270aeb221e6cc83dd6330e01900',1,'lum_tlv_adc_phase_offset_payload_struct']]],
  ['autophaseoverride',['autoPhaseOverride',['../structlum__tlv__auto__phase__override__payload__struct.html#ac37ace975b70e2a93a895f6dd24a586f',1,'lum_tlv_auto_phase_override_payload_struct']]],
  ['azimuth',['azimuth',['../structlum__angle__payload__struct.html#a90725441cd8c2e3e42f91c7a28641f2f',1,'lum_angle_payload_struct']]]
];
