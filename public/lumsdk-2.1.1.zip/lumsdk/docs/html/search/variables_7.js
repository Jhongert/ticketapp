var searchData=
[
  ['magic_5fnumber_5flong',['magic_number_long',['../structlum__tlv__packet.html#a24070e7ee79743d3be3ad4348f96fe0f',1,'lum_tlv_packet::magic_number_long()'],['../structlum__heartbeat__packet.html#a9250893ed7350945554949bcd9e0fd3c',1,'lum_heartbeat_packet::magic_number_long()'],['../structlum__timestamp__packet.html#a674a3fc7a16df18703f4bc770b38610a',1,'lum_timestamp_packet::magic_number_long()'],['../structlum__address__packet__struct.html#a924ff036bd93737e42c97aa4def65f3e',1,'lum_address_packet_struct::magic_number_long()']]],
  ['magic_5fnumber_5fshorts',['magic_number_shorts',['../structlum__tlv__packet.html#af2de6c8db8cdef61ac365bf6ff2ffa3c',1,'lum_tlv_packet::magic_number_shorts()'],['../structlum__heartbeat__packet.html#ad127dd6b59d60da69669602b87f2950a',1,'lum_heartbeat_packet::magic_number_shorts()'],['../structlum__timestamp__packet.html#a691495327cee7e4f76c33918dc449924',1,'lum_timestamp_packet::magic_number_shorts()'],['../structlum__address__packet__struct.html#a64996ac211a68c1217dd29382cf27505',1,'lum_address_packet_struct::magic_number_shorts()']]],
  ['max_5fnum_5freturns',['MAX_NUM_RETURNS',['../classlum_1_1FpgaClient3.html#a44de2a4aad8380133a1cdf62f61ca4d6',1,'lum::FpgaClient3']]],
  ['meter_5fper_5fbit',['METER_PER_BIT',['../namespacelum.html#ae195e8e8136e0b9d9c913e8f292368b0',1,'lum']]],
  ['missing_5freturn',['MISSING_RETURN',['../classlum_1_1FpgaClient3.html#a7e2af7e10ab0dc6f226da2d60ee0d672',1,'lum::FpgaClient3']]]
];
