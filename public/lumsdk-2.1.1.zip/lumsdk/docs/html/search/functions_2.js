var searchData=
[
  ['elevation_5fdeg_5fof_5fdisc_5felevation',['elevation_deg_of_disc_elevation',['../namespacelum.html#a7e82394f4a854e09772f340c8766e0b5',1,'lum']]]
];
