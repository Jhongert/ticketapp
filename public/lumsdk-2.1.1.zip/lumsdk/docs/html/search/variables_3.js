var searchData=
[
  ['first_5fsample_5findex',['first_sample_index',['../structlum__group__header.html#ab352f0dcd8ae09e956a7cee23012cfb1',1,'lum_group_header']]],
  ['first_5ftimestamp_5fus',['first_timestamp_us',['../structlum__group__header.html#acd3cbb01bd02e6b890a5d53e9ea9ec20',1,'lum_group_header']]],
  ['fpga_5fautophase_5foverride_5fparam',['FPGA_AUTOPHASE_OVERRIDE_PARAM',['../namespacelum.html#a96e2089a86f835c1d68d84fd951e5a02',1,'lum']]],
  ['fpga_5fblue_5fdetector_5fthreshold_5fparam',['FPGA_BLUE_DETECTOR_THRESHOLD_PARAM',['../namespacelum.html#a5a042b497c3b6b288b66b12ba2aca660',1,'lum']]],
  ['fpga_5fblue_5fgalvo_5foffset_5fparam',['FPGA_BLUE_GALVO_OFFSET_PARAM',['../namespacelum.html#a5f5357c04c7c2db6ca73c775a504c04d',1,'lum']]],
  ['fpga_5fgreen_5fdetector_5fthreshold_5fparam',['FPGA_GREEN_DETECTOR_THRESHOLD_PARAM',['../namespacelum.html#a677f6bfce5deec72d40725c89fedd3ff',1,'lum']]],
  ['fpga_5fgreen_5fgalvo_5foffset_5fparam',['FPGA_GREEN_GALVO_OFFSET_PARAM',['../namespacelum.html#a712fe836b1e3ef553774afbe09a7072f',1,'lum']]],
  ['fpga_5fholdoff_5fdelay_5fparam',['FPGA_HOLDOFF_DELAY_PARAM',['../namespacelum.html#a86cb371f96c7805532302f800296fa7e',1,'lum']]]
];
