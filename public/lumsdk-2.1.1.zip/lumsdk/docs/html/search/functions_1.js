var searchData=
[
  ['boost_5fmulti_5farray_5fof_5fros_5fmulti_5farray',['boost_multi_array_of_ros_multi_array',['../lumsdk__point__cloud__node_8cpp.html#a14298c7764a10805dbb095f3bbd4f78e',1,'boost_multi_array_of_ros_multi_array(const std_msgs::Int16MultiArray &amp;msg):&#160;lumsdk_point_cloud_node.cpp'],['../lumsdk__point__cloud__node_8cpp.html#a8651a2320f78184eff3576f848240962',1,'boost_multi_array_of_ros_multi_array(const std_msgs::Float32MultiArray &amp;msg):&#160;lumsdk_point_cloud_node.cpp']]]
];
