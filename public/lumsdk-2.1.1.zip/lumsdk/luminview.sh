#!/bin/bash
LUMSDK_ROOT_DIR="$(dirname $0)"

cd "$LUMSDK_ROOT_DIR"

source devel/setup.bash

roslaunch luminar_point_cloud luminview.launch
