#!/bin/bash
LUMSDK_ROOT_DIR="$(dirname $0)/../../.."

cd "$LUMSDK_ROOT_DIR/tools/LuminView/"

./LuminView.x86_64
