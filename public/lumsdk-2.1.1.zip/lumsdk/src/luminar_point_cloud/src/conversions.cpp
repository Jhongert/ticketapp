//
//
// conversions.cpp
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#include <assert.h>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <stdexcept>

#include "conversions.hpp"

namespace lum {

  /**
    * Factor to convert raw time of flight data into meters.
    * The time of flight is the time it takes to travel to the target and back from the target (twice the target distance).
    * The lsb of the time-of-flight measurement is 13pS.
    * - METER_PER_BIT = (3.0e8 m/s / 2) * 1e-12 s/ps * 13.0 ps/bit
    */
  const float METER_PER_BIT = 0.001948650977;

  lum::PointXYZ spherical(float azimuth_degrees, float polar_angle_degrees, float depth) {
    float azimuth_radians = azimuth_degrees * M_PI / 180.0;
    float polar_angle_radians = polar_angle_degrees * M_PI / 180.0;

    float x = depth * cos(azimuth_radians) * sin(polar_angle_radians);
    float y = depth * sin(azimuth_radians) * sin(polar_angle_radians);
    float z = depth * cos(polar_angle_radians);
    lum::PointXYZ point;
    point.x = x;
    point.y = y;
    point.z = z;
    return point;
  }

  float meter_of_disc_distance(const float disc_distance,
                               const float distance_offset) {
    return fmax(disc_distance * METER_PER_BIT + distance_offset, 0);
  }

  float azimuth_deg_of_disc_azimuth(const float disc_angle,
                                    const float azimuth_fov_degrees,
                                    const float azimuth_disc_min,
                                    const float azimuth_disc_max) {
    // Assume 0 discretized angle corresponds to 0 degrees field of view.
    const float degree_per_disc = azimuth_fov_degrees / (azimuth_disc_max - azimuth_disc_min);
    return disc_angle * degree_per_disc;
  }

  float elevation_deg_of_disc_elevation(const float disc_angle,
                                        const float elevation_min,
                                        const float elevation_max,
                                        const float elevation_disc_min,
                                        const float elevation_disc_max) {
    const float degree_per_disc = (elevation_max - elevation_min) /
      (elevation_disc_max - elevation_disc_min);
    return disc_angle * degree_per_disc + (elevation_min * elevation_disc_max - elevation_max * elevation_disc_min) / (elevation_disc_max - elevation_disc_min);
  }

} // namespace lum
