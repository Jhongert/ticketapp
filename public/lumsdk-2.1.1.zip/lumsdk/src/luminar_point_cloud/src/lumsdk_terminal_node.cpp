//
//
// lumsdk_terminal_node.cpp
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#include <thread>

#include <ros/ros.h>
#include <std_msgs/UInt8.h>
#include <std_msgs/Bool.h>

#include "lum_packet_format.h"
#include "lum_calibration_params.hpp"

#include "tlv/tlv_io.hpp"
#include "tlv/tlv_serializer.hpp"
#include "tlv/yscan/yscan.hpp"

#include "fpga-firmware/sw/lum_tlv_eth_protocol.h"

using namespace lum;

enum
{
    LASER_STAT_GALVO_AMP_BX_BAD  = 0x001,
    LASER_STAT_GALVO_AMP_BY_BAD  = 0x002,
    LASER_STAT_GALVO_AMP_GX_BAD  = 0x004,
    LASER_STAT_GALVO_AMP_GY_BAD  = 0x008,
    LASER_STAT_HEARTBEAT_TIMEOUT = 0x010,
    LASER_STAT_BOARD_OVER_105    = 0x020,
    LASER_STAT_FAN_PWM_BAD       = 0x040,
    LASER_STAT_HW_SAFETY_BAD     = 0x080,
    LASER_STAT_SYS_ON_SW_OFF     = 0x100,
    LASER_STAT_ALL_BAD           = 0x1ff,
};

static lum::TLVSerializer s_tlv_serializer;
static ros::Publisher s_pub_yscan = ros::Publisher();

static void send_tlv(lum::TLVIO& tlv_io, LUM_TLV* pTLVToSend) {
  std::vector<const LUM_TLV*> tlv_vec = {pTLVToSend};
  LUM_TLV_PACKET *tlv_packet = (LUM_TLV_PACKET*) malloc(MAX_TLV_PACKET_SIZE);
  int tlv_packet_tlvs_field_length =
    s_tlv_serializer.fill_tlv_packet_from_vec(tlv_vec,
                                              s_tlv_serializer.get_post_increment_sequence(),
                                              tlv_packet);
  tlv_io.send(tlv_packet, tlv_packet_tlvs_field_length);
  free(tlv_packet);
  s_tlv_serializer.free_tlv_vec(tlv_vec);
}

static void laser_state_change(lum::TLVIO& tlv_io, uint8_t laserState) {
  if (laserState != LUM_TLV_LASER_UP && laserState != LUM_TLV_LASER_DOWN) {
    return;
  }

  const uint16_t LUM_TLV_LENGTH = LUM_TLV_HEADER_SIZE + sizeof(LUM_TLV_LASER_STATE_PAYLOAD);
  LUM_TLV* pLaserStateTLV = (LUM_TLV*) malloc(LUM_TLV_LENGTH);
  pLaserStateTLV->type = LUM_TLV_LASER_STATE_TYPE;
  pLaserStateTLV->length = sizeof(LUM_TLV_LASER_STATE_PAYLOAD);

  LUM_TLV_LASER_STATE_PAYLOAD* pLaserStatePayload = (LUM_TLV_LASER_STATE_PAYLOAD*) &pLaserStateTLV->vector;
  pLaserStatePayload->laser_state_struct.laserState = laserState;

  send_tlv(tlv_io, pLaserStateTLV);
}

static void laser_up(lum::TLVIO& tlv_io) {
  laser_state_change(tlv_io, LUM_TLV_LASER_UP);
}

static void laser_down(lum::TLVIO& tlv_io) {
  laser_state_change(tlv_io, LUM_TLV_LASER_DOWN);
}

static void auto_phase_override_set(lum::TLVIO& tlv_io, bool autoPhaseOverride)
{
  const uint16_t LUM_TLV_LENGTH = LUM_TLV_HEADER_SIZE + sizeof(LUM_TLV_AUTO_PHASE_OVERRIDE_PAYLOAD);
  LUM_TLV* pautoPhaseOverrideTLV = (LUM_TLV*) malloc(LUM_TLV_LENGTH);
  pautoPhaseOverrideTLV->type = LUM_TLV_AUTO_PHASE_OVERRIDE_TYPE;
  pautoPhaseOverrideTLV->length = sizeof(LUM_TLV_AUTO_PHASE_OVERRIDE_PAYLOAD);

  LUM_TLV_AUTO_PHASE_OVERRIDE_PAYLOAD* pAutoPhaseOverridePayload = (LUM_TLV_AUTO_PHASE_OVERRIDE_PAYLOAD*) &pautoPhaseOverrideTLV->vector;
  pAutoPhaseOverridePayload->autoPhaseOverride = autoPhaseOverride ? 1 : 0;

  send_tlv(tlv_io, pautoPhaseOverrideTLV);
}

static void request_laser_status(lum::TLVIO& tlv_io) {

  const uint16_t LUM_TLV_LENGTH = LUM_TLV_HEADER_SIZE;
  LUM_TLV* pLaserStatusTLV = (LUM_TLV*) malloc(LUM_TLV_LENGTH);
  pLaserStatusTLV->type = LUM_TLV_LASER_STATUS_TYPE;
  pLaserStatusTLV->length = 0;

  send_tlv(tlv_io, pLaserStatusTLV);
}

static void set_t0_distance(float t0Distance)
{
  if (t0Distance >= 0)
  {
    ros::param::set("t0_distance_cutoff", t0Distance);
  }
}

static void laser_power_set(lum::TLVIO& tlv_io, unsigned int power) {
  const uint16_t LUM_TLV_LENGTH = LUM_TLV_HEADER_SIZE + sizeof(LUM_TLV_LASER_POWER_PAYLOAD);
  LUM_TLV* pLaserPowerTLV = (LUM_TLV*) malloc(LUM_TLV_LENGTH);
  pLaserPowerTLV->type = LUM_TLV_LASER_POWER_TYPE;
  pLaserPowerTLV->length = sizeof(LUM_TLV_LASER_POWER_PAYLOAD);

  LUM_TLV_LASER_POWER_PAYLOAD* pLaserPowerPayload = (LUM_TLV_LASER_POWER_PAYLOAD*) &pLaserPowerTLV->vector;
  pLaserPowerPayload->power = power;

  send_tlv(tlv_io, pLaserPowerTLV);
}

static void set_threshold(lum::TLVIO& tlv_io, uint16_t type, unsigned int threshold) {
  const uint16_t LUM_TLV_LENGTH = LUM_TLV_HEADER_SIZE + sizeof(LUM_TLV_THRESHOLD_PAYLOAD);
  LUM_TLV* pThresholdTLV = (LUM_TLV*) malloc(LUM_TLV_LENGTH);
  pThresholdTLV->type = type;
  pThresholdTLV->length = sizeof(LUM_TLV_THRESHOLD_PAYLOAD);

  LUM_TLV_THRESHOLD_PAYLOAD* pThresholdPayload = (LUM_TLV_THRESHOLD_PAYLOAD*) &pThresholdTLV->vector;
  pThresholdPayload->threshold = threshold;

  send_tlv(tlv_io, pThresholdTLV);
}

static void blue_threshold_set(lum::TLVIO& tlv_io, unsigned int threshold) {
  set_threshold(tlv_io, LUM_TLV_BLUE_THRESHOLD_TYPE, threshold);
}

static void green_threshold_set(lum::TLVIO& tlv_io, unsigned int threshold) {
  set_threshold(tlv_io, LUM_TLV_GREEN_THRESHOLD_TYPE, threshold);
}

static void set_adc_phase_offset(lum::TLVIO& tlv_io, uint16_t type, unsigned int adcPhaseOffset) {
  const uint16_t LUM_TLV_LENGTH = LUM_TLV_HEADER_SIZE + sizeof(LUM_TLV_ADC_PHASE_OFFSET_PAYLOAD);
  LUM_TLV* pADCOffsetTLV = (LUM_TLV*) malloc(LUM_TLV_LENGTH);
  pADCOffsetTLV->type = type;
  pADCOffsetTLV->length = sizeof(LUM_TLV_ADC_PHASE_OFFSET_PAYLOAD);

  LUM_TLV_ADC_PHASE_OFFSET_PAYLOAD* pADCOffsetPayload = (LUM_TLV_ADC_PHASE_OFFSET_PAYLOAD*) &pADCOffsetTLV->vector;
  pADCOffsetPayload->adcPhaseOffset = adcPhaseOffset;

  send_tlv(tlv_io, pADCOffsetTLV);
}

static void blue_adc_phase_offset_set(lum::TLVIO& tlv_io, unsigned int adcPhaseOffset) {
  set_adc_phase_offset(tlv_io, LUM_TLV_ADC_PHASE_OFFSET_BLUE_TYPE, adcPhaseOffset);
}

static void green_adc_phase_offset_set(lum::TLVIO& tlv_io, unsigned int adcPhaseOffset) {
  set_adc_phase_offset(tlv_io, LUM_TLV_ADC_PHASE_OFFSET_GREEN_TYPE, adcPhaseOffset);
}

static void holdoff_time_set(lum::TLVIO& tlv_io, unsigned int holdoff) {
  const uint16_t LUM_TLV_LENGTH = LUM_TLV_HEADER_SIZE + sizeof(LUM_TLV_HOLDOFF_PAYLOAD);
  LUM_TLV* pHoldoffTLV = (LUM_TLV*) malloc(LUM_TLV_LENGTH);
  pHoldoffTLV->type = LUM_TLV_HOLDOFF_TYPE;
  pHoldoffTLV->length = sizeof(LUM_TLV_HOLDOFF_PAYLOAD);

  LUM_TLV_HOLDOFF_PAYLOAD* pHoldoffPayload = (LUM_TLV_HOLDOFF_PAYLOAD*) &pHoldoffTLV->vector;
  pHoldoffPayload->holdoff = holdoff;

  send_tlv(tlv_io, pHoldoffTLV);
}

static void yscan_set(
  lum::TLVIO& tlv_io,
  std::array<int16_t, NUM_Y_STEPS> scan_millidegrees,
  uint32_t eye_type
) {
  if (!scan_pattern_eye_safe(scan_millidegrees)) {
    ROS_ERROR("NOT EYESAFE SCAN REQUESTED!");
    return;
  }

  if (scan_millidegrees[0] < YMIN_MILLIDEGREES ||
      scan_millidegrees[NUM_Y_STEPS - 1] > YMAX_MILLIDEGREES) {
    ROS_ERROR("Invalid SCAN REQUESTED!");
    return;
  }

  const uint16_t LUM_TLV_LENGTH = LUM_TLV_HEADER_SIZE + sizeof(YSCAN2_PACKET);
  LUM_TLV* pYscanTLV = (LUM_TLV*) malloc(LUM_TLV_LENGTH);
  pYscanTLV->type = eye_type;
  pYscanTLV->length = sizeof(YSCAN2_PACKET);

  YSCAN2_PACKET* pYscanPayload = (YSCAN2_PACKET*) &pYscanTLV->vector;
  std::copy(scan_millidegrees.begin(), scan_millidegrees.end(), pYscanPayload->yscan_positions);

  send_tlv(tlv_io, pYscanTLV);
}

static void uniform_fov_set(lum::TLVIO& tlv_io, unsigned int fov) {
  float horizon_angle = 0.f;
  // if (!ros::param::getCached(lum::HORIZON_ANGLE_DEGREES, horizon_angle)) {
  //   horizon_angle = 0;
  // }
  //horizon_angle /= 2;

  float amp = MILLIDEGREES(fov) / 2;
  float min = horizon_angle - amp;
  float max = horizon_angle + amp;

  // Set yscan for both eyes
  for (const auto& type: {LUM_TLV_YSCAN2_GREEN_TYPE, LUM_TLV_YSCAN2_BLUE_TYPE})  {
    bool should_flip;
    const std::string should_flip_param_name =
      (type == LUM_TLV_YSCAN2_GREEN_TYPE) ? lum::GREEN_FLIP_PARAM : lum::BLUE_FLIP_PARAM;
    if (!ros::param::getCached(should_flip_param_name, should_flip)) {
      ROS_ERROR("YSCAN TLV: flip param not set");
    }

    float eye_min, eye_max;
    if (!should_flip) {
      eye_min = -max;
      eye_max = -min;
    } else {
      eye_min = min;
      eye_max = max;
    }

    auto scan_millidegrees = uniform_scan(eye_min, eye_max);

    yscan_set(tlv_io, scan_millidegrees, type);
  }
}

template<typename TLV_FIXED_PAYLOAD>
const TLV_FIXED_PAYLOAD* to_tlv_payload_type(const LUM_TLV* p_tlv) {
  if (p_tlv != nullptr) {
    const TLV_FIXED_PAYLOAD* p_tlv_payload = (TLV_FIXED_PAYLOAD*)&p_tlv->vector;
    return p_tlv_payload;
  } else {
    return nullptr;
  }
}

static void updateYscan(std::array<int16_t, NUM_Y_STEPS>&  scan_millidegrees, uint16_t type) {
  float max_elevation_angle = *std::max_element(scan_millidegrees.begin(), scan_millidegrees.end()) / 1000.;
  float min_elevation_angle = *std::min_element(scan_millidegrees.begin(), scan_millidegrees.end()) / 1000.;

  bool should_flip;
  const std::string should_flip_param_name =
    (type == LUM_TLV_YSCAN2_GREEN_TYPE) ? lum::GREEN_FLIP_PARAM : lum::BLUE_FLIP_PARAM;
  if (!ros::param::getCached(should_flip_param_name, should_flip)) {
    ROS_ERROR("YSCAN TLV: flip param not set");
  }

  if (should_flip) {
    std::swap(min_elevation_angle, max_elevation_angle);
    min_elevation_angle *= -1;
    max_elevation_angle *= -1;
  }

  float elevation_offset;
  const std::string elevation_offset_param_name =
    (type == LUM_TLV_YSCAN2_GREEN_TYPE) ? lum::GREEN_ELEVATION_CENTER_DEGREES : lum::BLUE_ELEVATION_CENTER_DEGREES;
  if (!ros::param::getCached(elevation_offset_param_name, elevation_offset) ) {
    ROS_ERROR("YSCAN TLV: No value set for elevation_offset");
  }

  min_elevation_angle += elevation_offset;
  max_elevation_angle += elevation_offset;

  if (type == LUM_TLV_YSCAN2_BLUE_TYPE) {
    ros::param::set(BLUE_HIGHEST_ALTITUDE_DEGREES_PARAM, max_elevation_angle);
    ros::param::set(BLUE_LOWEST_ALTITUDE_DEGREES_PARAM, min_elevation_angle);
  } else {
    ros::param::set(GREEN_HIGHEST_ALTITUDE_DEGREES_PARAM, max_elevation_angle);
    ros::param::set(GREEN_LOWEST_ALTITUDE_DEGREES_PARAM, min_elevation_angle);
  }
}

static bool on_client_received_tlv_packet(lum::TLVIO&, const LUM_TLV_PACKET* tlv_packet,
                                          std::size_t tlvs_field_length) {
  auto received_vec =
    s_tlv_serializer.allocate_tlv_vec_from_packet(tlv_packet, tlvs_field_length);

  for (const LUM_TLV* p_tlv : received_vec) {
    if ((p_tlv->type & (uint16_t)LUM_TLV_RESPONSE_MASK) == 0) {
      std::cout << "ERROR: Response came from a non-server" << std::endl;
      continue;
    }

    uint16_t msb_mask = ~static_cast<uint16_t>(LUM_TLV_RESPONSE_MASK);
    auto type = msb_mask & p_tlv->type;

    // Print results

    switch(type) {
      // laser state
      case LUM_TLV_LASER_STATE_TYPE:
      {
        const LUM_TLV_LASER_STATE_PAYLOAD* p_state_payload = to_tlv_payload_type<LUM_TLV_LASER_STATE_PAYLOAD>(p_tlv);
        if (p_state_payload == nullptr) {
          break;
        }

        auto state = p_state_payload->laser_state_struct.laserState;

        std::string laser_state_str = (state == LUM_LASER_ON) ? "ON"
          : (state == LUM_LASER_DOWN) ? "OFF"
          : (state == LUM_LASER_UNKNOWN) ? "state UNKNOWN"
          : "warming up";
        std::cout << "Laser " << laser_state_str << std::endl;
        break;
      }

      // laser power
      case LUM_TLV_LASER_POWER_TYPE:
      {
        const LUM_TLV_LASER_POWER_PAYLOAD* p_power_payload = to_tlv_payload_type<LUM_TLV_LASER_POWER_PAYLOAD>(p_tlv);
        if (p_power_payload == nullptr) {
          break;
        }

        std::cout << "Laser power " << p_power_payload->power << std::endl;
        break;
      }

      // thresholds
      case LUM_TLV_BLUE_THRESHOLD_TYPE:
      {
        // Don't break, move on to green
      }

      case LUM_TLV_GREEN_THRESHOLD_TYPE:
      {
        const LUM_TLV_THRESHOLD_PAYLOAD* p_threshold_payload = to_tlv_payload_type<LUM_TLV_THRESHOLD_PAYLOAD>(p_tlv);
        if (p_threshold_payload == nullptr) {
          break;
        }

        std::cout << ((type == LUM_TLV_BLUE_THRESHOLD_TYPE) ? "Blue" : "Green")
                  << " threshold " << p_threshold_payload->threshold << std::endl;
        break;
      }

      // adc phase offset
      case LUM_TLV_ADC_PHASE_OFFSET_BLUE_TYPE:
      {
        // Don't break, move on to green
      }

      case LUM_TLV_ADC_PHASE_OFFSET_GREEN_TYPE:
      {
        const LUM_TLV_ADC_PHASE_OFFSET_PAYLOAD* p_adc_offset_payload = to_tlv_payload_type<LUM_TLV_ADC_PHASE_OFFSET_PAYLOAD>(p_tlv);
        if (p_adc_offset_payload == nullptr) {
          break;
        }

        std::cout << ((type == LUM_TLV_ADC_PHASE_OFFSET_BLUE_TYPE) ? "Blue" : "Green")
                  << " ADC Phase Offset " << p_adc_offset_payload->adcPhaseOffset << std::endl;
        break;
      }

      case LUM_TLV_AUTO_PHASE_OVERRIDE_TYPE:
      {
        const LUM_TLV_AUTO_PHASE_OVERRIDE_PAYLOAD* p_auto_phase_override_payload = to_tlv_payload_type<LUM_TLV_AUTO_PHASE_OVERRIDE_PAYLOAD>(p_tlv);
        if (p_auto_phase_override_payload == nullptr) {
          break;
        }

        std::cout << " Auto Phase Override: " << (p_auto_phase_override_payload->autoPhaseOverride == 1 ? "True" : "False") << std::endl;
        break;
      }

      // yscan
      case LUM_TLV_YSCAN2_BLUE_TYPE:
      {
        // Don't break, move on to green
      }

      case LUM_TLV_YSCAN2_GREEN_TYPE:
      {
        std::cout << "YSCAN set" << std::endl;
        const YSCAN2_PACKET* p_yscan_payload = (YSCAN2_PACKET*)&p_tlv->vector;
        std::array<int16_t, NUM_Y_STEPS> scan_millidegrees;
        std::copy(p_yscan_payload->yscan_positions, p_yscan_payload->yscan_positions + NUM_HORIZONTAL_LINES,
                  scan_millidegrees.begin());
        updateYscan(scan_millidegrees, type);
        break;
      }

      case LUM_TLV_HOLDOFF_TYPE:
      {
        const LUM_TLV_HOLDOFF_PAYLOAD* p_holdoff_payload = to_tlv_payload_type<LUM_TLV_HOLDOFF_PAYLOAD>(p_tlv);
        if (p_holdoff_payload == nullptr) {
          break;
        }

        std::cout << "Holdoff delay: " << p_holdoff_payload->holdoff << " ns" << std::endl;
        break;
      }
      case LUM_TLV_LASER_STATUS_TYPE:
      {
        const LUM_TLV_LASER_STATUS_PAYLOAD* p_laser_status_payload = to_tlv_payload_type<LUM_TLV_LASER_STATUS_PAYLOAD>(p_tlv);
        if (p_laser_status_payload == nullptr) {
          break;
        }

        unsigned int status = p_laser_status_payload->status;

        printf(" : Heartbeat: %s\n",
                (!(status & LASER_STAT_HEARTBEAT_TIMEOUT)) ? "OK" : "TIMEOUT");

        printf(" : Galvo amp: BX=%s  BY=%s  GX=%s  GY=%s\n",
                (!(status & LASER_STAT_GALVO_AMP_BX_BAD)) ? "OK" : "BAD",
                (!(status & LASER_STAT_GALVO_AMP_BY_BAD)) ? "OK" : "BAD",
                (!(status & LASER_STAT_GALVO_AMP_GX_BAD)) ? "OK" : "BAD",
                (!(status & LASER_STAT_GALVO_AMP_GY_BAD)) ? "OK" : "BAD");

        printf(" : Board temp: %s\n",
                (!(status & LASER_STAT_BOARD_OVER_105))    ? "OK" : "> 105C");

        printf(" : Fan: %s\n",
                (!(status & LASER_STAT_FAN_PWM_BAD))       ? "OK" : "not running");

        printf(" : HW Safety or heartbeat loss or tack loss or overtemp or sys switch: %s\n",
                (!(status & LASER_STAT_HW_SAFETY_BAD))     ? "OK" : "BAD");


        break;
      }

      default:
      {
        std::cout << "Client received TLV of type " << p_tlv->type << std::endl;
        break;
      }
    }
  }
  return true;
}

int main(int argc, char **argv) {
  // Init ROS Node
  ros::init(argc, argv, "lumsdk_terminal_node");
  ros::start();
  ros::NodeHandle nh;

  s_pub_yscan = nh.advertise<std_msgs::Bool>("/luminar_yscan_changed", 2);

  boost::asio::ip::udp::endpoint fpga_endpoint(
    boost::asio::ip::address_v4(LUM_LIDAR_IP_ADDRESS),
    LUM_LIDAR_PORT);

  TLVIO tlv_io(fpga_endpoint, on_client_received_tlv_packet, 0L);

  int blue_galvo_offset = 10;
  int green_galvo_offset = 10;
  int green_threshold = 17;
  int blue_threshold = 17;
  int holdoff_delay = 160;
  bool auto_phase_override = true;
  if (!ros::param::getCached(lum::FPGA_BLUE_GALVO_OFFSET_PARAM, blue_galvo_offset) ||
      !ros::param::getCached(lum::FPGA_GREEN_GALVO_OFFSET_PARAM, green_galvo_offset) ||
      !ros::param::getCached(lum::FPGA_GREEN_DETECTOR_THRESHOLD_PARAM, green_threshold) ||
      !ros::param::getCached(lum::FPGA_BLUE_DETECTOR_THRESHOLD_PARAM, blue_threshold) ||
      !ros::param::getCached(lum::FPGA_HOLDOFF_DELAY_PARAM, holdoff_delay) ||
      !ros::param::getCached(lum::FPGA_AUTOPHASE_OVERRIDE_PARAM, auto_phase_override))
  {
    ROS_ERROR("No value set for FPGA parameter");
  }



  //Set parameters from .yaml file
  blue_threshold_set(tlv_io, blue_threshold);
  green_threshold_set(tlv_io, green_threshold);
  uniform_fov_set(tlv_io, 30); // set to 30deg fov
  auto_phase_override_set(tlv_io, auto_phase_override);
  blue_adc_phase_offset_set(tlv_io, blue_galvo_offset);
  green_adc_phase_offset_set(tlv_io, green_galvo_offset);
  holdoff_time_set(tlv_io, holdoff_delay);
  std::cout << "Welcome to Luminar's Ethernet Command Terminal!\n";
  std::thread terminal_thread([&]() {
    std::string command;
    std::cout << "Luminar> ";
    while (std::getline(std::cin, command)) {
      if (command != "") {
        const char last_char = command.back();

        try {
          if (last_char == 'u') {
            laser_up(tlv_io);
          } else if (last_char == 'd') {
            laser_down(tlv_io);
          } else if (last_char == 'p') {
            command.pop_back();
            unsigned int power = std::stoi(command);
            laser_power_set(tlv_io, power);
          } else if (last_char == 'b') {
            command.pop_back();
            unsigned int threshold = std::stoi(command);
            blue_threshold_set(tlv_io, threshold);
          } else if (last_char == 'g') {
            command.pop_back();
            unsigned int threshold = std::stoi(command);
            green_threshold_set(tlv_io, threshold);
          } else if (last_char == 'B') {
            command.pop_back();
            unsigned int adcPhaseOffset = std::stoi(command);
            blue_adc_phase_offset_set(tlv_io, adcPhaseOffset);
          } else if (last_char == 'G') {
            command.pop_back();
            unsigned int adcPhaseOffset = std::stoi(command);
            green_adc_phase_offset_set(tlv_io, adcPhaseOffset);
          } else if (last_char == 'y') {
            command.pop_back();
            unsigned int fov = std::stoi(command);
            uniform_fov_set(tlv_io, fov);
          } else if (last_char == 'h') {
            command.pop_back();
            unsigned int holdoff = std::stoi(command);
            holdoff_time_set(tlv_io, holdoff);
          } else if (last_char == 's') {
            request_laser_status(tlv_io);
          }
          else if (last_char == 't')
          {
            command.pop_back();
            float t0Distance = std::stof(command);
            set_t0_distance(t0Distance);
          }
        } catch (const std::invalid_argument& ia) {
          std::cerr << "Invalid argument: " << ia.what() << std::endl;
        }
      }
      std::cout << "Luminar> ";
    }
    // stdin was closed by Ctrl-D
    exit(0);
  });

  tlv_io.run();

  return 0;
}
