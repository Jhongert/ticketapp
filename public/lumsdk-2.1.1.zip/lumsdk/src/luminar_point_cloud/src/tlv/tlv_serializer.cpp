//
//
// tlv_serializer.cpp
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#include <string.h>
#include "tlv/tlv_serializer.hpp"

namespace lum {

  TLVSerializer::TLVSerializer()
    : sequence_(0) {
  }


  int TLVSerializer::fill_tlv_packet_from_vec(const std::vector<const LUM_TLV*>& tlv_vec,
                                              uint32_t sequence, LUM_TLV_PACKET* p_tlv_packet) const {

    if (p_tlv_packet == nullptr) {
      return -1;
    }

    memset(p_tlv_packet, 0, sizeof(*p_tlv_packet));
    p_tlv_packet->magic_number_shorts[0] = TLV_PACKET_MAGIC_SHORT_0;
    p_tlv_packet->magic_number_shorts[1] = TLV_PACKET_MAGIC_SHORT_1;
    p_tlv_packet->magic_number_shorts[2] = TLV_PACKET_MAGIC_SHORT_2;
    p_tlv_packet->magic_number_shorts[3] = TLV_PACKET_MAGIC_SHORT_3;
    p_tlv_packet->packet_type = LUM_TLV_PACKET_TYPE;
    p_tlv_packet->sequence = sequence;

    std::size_t cur_tlvs_pos = 0;

    for (const LUM_TLV* p_cur_tlv : tlv_vec) {

      if (p_cur_tlv == nullptr) {
        continue;
      }

      std::size_t cur_tlv_len = LUM_TLV_HEADER_SIZE + p_cur_tlv->length;

      void* p_dest = (void*)(((uint8_t*)p_tlv_packet) + TLV_PACKET_HEADER_SIZE + cur_tlvs_pos);

      std::size_t new_tlvs_pos = cur_tlvs_pos + cur_tlv_len;

      if (new_tlvs_pos <= MAX_TLV_PAYLOAD_SIZE) {
        memcpy(p_dest, p_cur_tlv, cur_tlv_len);
        cur_tlvs_pos = new_tlvs_pos;
      } else {
        return -1;
      }
    }

    return cur_tlvs_pos;
  }

    std::vector<const LUM_TLV*>
    TLVSerializer::allocate_tlv_vec_from_packet(const LUM_TLV_PACKET* tlv_packet,
                                                std::size_t tlvs_field_length) const {

    std::vector<const LUM_TLV*> tlv_vec;

    const LUM_TLV* p_cur_tlv = (LUM_TLV*)(((uint8_t*)tlv_packet) + (std::size_t)TLV_PACKET_HEADER_SIZE);

    std::size_t cur_tlvs_pos = 0;

    while (cur_tlvs_pos < tlvs_field_length) {

      std::size_t cur_tlv_len = LUM_TLV_HEADER_SIZE + p_cur_tlv->length;

      // NOTE: not sure if I like that the only way you can check if the LUM_TLV from a LUM_TLV_PACKET buffer is valid
      // is whether the length field is non-zero. We have no 'length' field from the LUM_TLV_PACKET so unfilled
      // LUM_TLV_PACKET buffers will have to be iterated through and cannot stop prematurely.
      if (p_cur_tlv->length > 0) {

        const LUM_TLV& cur_tlv = *p_cur_tlv;

        // allocate a copy of the TLV so that memory for LUM_TLV is not based upon addresses of LUM_TLV_PACKET
        const LUM_TLV* p_allocated_tlv = allocate_tlv_from_packet_buffer(cur_tlv);

        tlv_vec.push_back(p_allocated_tlv);
      }

      cur_tlvs_pos += cur_tlv_len;
      p_cur_tlv = (LUM_TLV*)(((uint8_t*)tlv_packet) + TLV_PACKET_HEADER_SIZE + cur_tlvs_pos);
    }

    // caller is responsible for freeing memory allocated for each TLV
    return tlv_vec;
  }

  const LUM_TLV* TLVSerializer::allocate_tlv_from_packet_buffer(const LUM_TLV& tlv_from_buffer) const {

    std::size_t cur_tlv_len = LUM_TLV_HEADER_SIZE + tlv_from_buffer.length;

    LUM_TLV* p_tlv = (LUM_TLV*)malloc(cur_tlv_len);

    memcpy(p_tlv, &tlv_from_buffer, cur_tlv_len);

    return p_tlv;
  }

  void TLVSerializer::free_tlv_vec(const std::vector<const LUM_TLV*>& tlv_vec) const {
    for (const LUM_TLV* p_tlv : tlv_vec) {
      // NOTE: we want the data pointed to by LUM_TLV* read-only typically
      // but we still need to be able to edit it for deletion since it is dynamically allocated
      free(const_cast<LUM_TLV*>(p_tlv));
    }
  }

}
