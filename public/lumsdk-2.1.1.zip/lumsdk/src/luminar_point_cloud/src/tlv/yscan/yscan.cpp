//
//
// yscan.cpp
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#include <algorithm>
#include <array>
#include <cassert>
#include <vector>

#include "tlv/yscan/yscan.hpp"

namespace lum {

  float interpolate(float x, float y, float alpha) {
    return x * (1 - alpha) + alpha * y;
  }

  std::array<int16_t, NUM_Y_STEPS> uniform_scan(float min_millidegrees,
                                                float max_millidegrees) {
    // Validate input params
    assert(min_millidegrees >= YMIN_MILLIDEGREES);
    assert(max_millidegrees <= YMAX_MILLIDEGREES);

    std::array<int16_t, NUM_Y_STEPS> pattern;

    for(std::size_t i = 0; i < NUM_Y_STEPS; i++) {
      float alpha = static_cast<float>(i) / (NUM_Y_STEPS - 1);
      float millidegrees = interpolate(min_millidegrees, max_millidegrees, alpha);

      pattern[i] = static_cast<int16_t>(std::round(millidegrees));
    }

    return pattern;
  }

  bool scan_pattern_eye_safe(const std::array<int16_t, NUM_Y_STEPS>& pattern) {
    for (unsigned int i = 0; i < pattern.size() - 1; i++) {
      if (pattern[i + 1] - pattern[i] < MIN_SAFE_STEP_SIZE) {
        return false;
      }
    }
    return true;
  }
}
