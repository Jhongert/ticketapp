//
//
// tlv_io.cpp
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#pragma GCC diagnostic ignored "-Wmissing-field-initializers"

#include "tlv/tlv_io.hpp"
#include <sstream>
#include <iostream>

namespace lum {

  static std::string get_hhmmss() {
    time_t now = time(0);
    char timestamp[10] = "";
    strftime (timestamp, 10,"[%H:%M:%S] ", localtime(&now));
    return timestamp;
  }

  TLVIO::TLVIO(const boost::asio::ip::udp::endpoint& dest_endpoint,
               uint16_t src_port,
               std::function<bool(TLVIO&, const LUM_TLV_PACKET*, std::size_t)> receive_tlv_packet_func,
               long resend_period_sec)
    : received_tlv_packet_(nullptr),
      io_service_(),
      socket_(io_service_,
          boost::asio::ip::udp::endpoint(boost::asio::ip::address(boost::asio::ip::address_v4(INADDR_ANY)), src_port)),
      dest_endpoint_(dest_endpoint),
      resend_timer_period_sec_(resend_period_sec),
      resend_packet_timer_(io_service_, boost::posix_time::seconds(resend_timer_period_sec_)),
      received_from_endpoint_(),
      receive_tlv_packet_func_(receive_tlv_packet_func)
  {
    received_tlv_packet_ = (LUM_TLV_PACKET*) malloc(MAX_TLV_PACKET_SIZE);
  }

  TLVIO::TLVIO(const boost::asio::ip::udp::endpoint& dest_endpoint,
               std::function<bool(TLVIO&, const LUM_TLV_PACKET*, std::size_t)> receive_tlv_packet_func,
               long resend_period_sec)
    : received_tlv_packet_(nullptr),
      io_service_(),
      socket_(io_service_, boost::asio::ip::udp::v4()),
      dest_endpoint_(dest_endpoint),
      resend_timer_period_sec_(resend_period_sec),
      resend_packet_timer_(io_service_, boost::posix_time::seconds(resend_timer_period_sec_)),
      received_from_endpoint_(),
      receive_tlv_packet_func_(receive_tlv_packet_func)
  {
    received_tlv_packet_ = (LUM_TLV_PACKET*) malloc(MAX_TLV_PACKET_SIZE);
  }

  TLVIO::~TLVIO() {
    free(received_tlv_packet_);

    for (const auto& kvp_tlv_packet : sent_tlv_packets_) {
      const auto &packet_pair = kvp_tlv_packet.second;
      LUM_TLV_PACKET *tlv_packet = packet_pair.first;
      free(tlv_packet);
    }
  }

  void TLVIO::run() {
    setup_socket_to_receive();
    io_service_.run();
  }

  void TLVIO::stop() {
    io_service_.stop();
  }


  void TLVIO::send(const LUM_TLV_PACKET* tlv_packet, std::size_t tlvs_field_length) {
    socket_.send_to(boost::asio::buffer(tlv_packet, TLV_PACKET_HEADER_SIZE + tlvs_field_length),
                    dest_endpoint_);

    // Only store sent packets if we care about resending them if
    // they don't get acknowledged
    if (should_resend_unacknowledged_packets()) {
      // Make a copy of the tlv_packet in case we need to send it again.
      LUM_TLV_PACKET *tlv_packet_copy =
        (LUM_TLV_PACKET*) malloc(TLV_PACKET_HEADER_SIZE + tlvs_field_length);
      memcpy(tlv_packet_copy, tlv_packet, TLV_PACKET_HEADER_SIZE + tlvs_field_length);
      sent_tlv_packets_[tlv_packet->sequence] =
        std::make_pair(tlv_packet_copy, TLV_PACKET_HEADER_SIZE + tlvs_field_length);
    }
  }

  void TLVIO::setup_socket_to_receive() {

    if (should_resend_unacknowledged_packets()) {
      resend_packet_timer_.async_wait(boost::bind(&TLVIO::on_resend_packet_timer_tick, this,
        boost::asio::placeholders::error, &resend_packet_timer_, nullptr));
    }

    socket_.async_receive_from(
      boost::asio::buffer(received_tlv_packet_, MAX_TLV_PACKET_SIZE),
      received_from_endpoint_,
      boost::bind(&TLVIO::handle_receive_from, this,
                  boost::asio::placeholders::error,
                  boost::asio::placeholders::bytes_transferred)
      );
  }

  void TLVIO::handle_receive_from(const boost::system::error_code& error, size_t bytes_recvd) {

    if (received_from_endpoint_ != dest_endpoint_) {
      return;
    }

    // TODO: How many bytes are sent?
    if (error || bytes_recvd > MAX_TLV_PACKET_SIZE) {
      std::cout << "ERROR: Received data was not a TLV Packet" << std::endl;
      return;
    }

    if (received_tlv_packet_->packet_type != LUM_TLV_PACKET_TYPE) {
        std::cout << "ERROR: TLV Packet is not of the right type" << std::endl;
        return;
    }

    if (!(received_tlv_packet_->magic_number_shorts[0] == TLV_PACKET_MAGIC_SHORT_0 &&
          received_tlv_packet_->magic_number_shorts[1] == TLV_PACKET_MAGIC_SHORT_1 &&
          received_tlv_packet_->magic_number_shorts[2] == TLV_PACKET_MAGIC_SHORT_2 &&
          received_tlv_packet_->magic_number_shorts[3] == TLV_PACKET_MAGIC_SHORT_3)) {
      std::cout << "ERROR: TLV Packet has been corrupted" << std::endl;
      return;
    }


    // Mark packet as received if we care about making
    //  sure all packets are acknowledged
    if (should_resend_unacknowledged_packets()) {
      free(sent_tlv_packets_.at(received_tlv_packet_->sequence).first);
      sent_tlv_packets_.erase(received_tlv_packet_->sequence);
    }

    // give io_service more work to do unless io_service_.run() would finish
    setup_socket_to_receive();

    // user defined callback
    receive_tlv_packet_func_(*this, received_tlv_packet_, bytes_recvd - TLV_PACKET_HEADER_SIZE);
  }

  void TLVIO::on_resend_packet_timer_tick(const boost::system::error_code& e,
                                          boost::asio::deadline_timer* p_resend_packet_timer,
                                          int*) {
    if (e) {
      return;
    }

    if (p_resend_packet_timer == nullptr) {
      assert(p_resend_packet_timer);
      return;
    }

    resend_unacknowledged_packets();

    // respawn deadline timer to tick again and check for any unacknowledged packets
    p_resend_packet_timer->expires_from_now(boost::posix_time::seconds(resend_timer_period_sec_));
    p_resend_packet_timer->async_wait(boost::bind(&TLVIO::on_resend_packet_timer_tick, this,
                                                  boost::asio::placeholders::error, p_resend_packet_timer, nullptr));
  }

  void TLVIO::resend_unacknowledged_packets() {
    for (const auto& kvp_tlv_packet : sent_tlv_packets_) {
      const auto &packet_pair = kvp_tlv_packet.second;
      LUM_TLV_PACKET* tlv_packet = packet_pair.first;
      std::size_t tlvs_field_length = packet_pair.second;

      std::cout << get_hhmmss() << "resending packet sequence number " <<
        tlv_packet->sequence << std::endl;

      socket_.send_to(boost::asio::buffer(&tlv_packet, TLV_PACKET_HEADER_SIZE + tlvs_field_length),
                      dest_endpoint_);
    }
  }

}
