#include <chrono>
#include <thread>

#include <boost/asio.hpp>

#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>

#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>

using boost::asio::ip::udp;

#define MAX_RETURNS 8
#define NUM_EDGES 2

int main(int argc, char **argv) {
  // Ros variables
  ros::init(argc, argv, "lumsdk_unity_node");
  ros::start();
  ros::NodeHandle nh;

  // UDP client for unity
  const std::string UNITY_VIZ_IP = "127.0.0.1";
  const std::string UNITY_VIZ_PORT = "6006";
  const int UNITY_MAX_UDP_POINTS = 2000;
  const int NUM_POINTS_10HZ_FRAME = 2 * 64 * 1000;

  boost::asio::io_service io_service;
  udp::socket socket(io_service, udp::endpoint(udp::v4(), 0));
  udp::resolver resolver(io_service);
  udp::resolver::query query(udp::v4(), UNITY_VIZ_IP, UNITY_VIZ_PORT);
  udp::endpoint endpoint = *resolver.resolve(query);

  // Struct to send to unity
  int frame_counter = 0;
  struct UNITY_UDP_PACKET {
    // points array is list of x,y,z points (hence 3x multiplier)
    float points[UNITY_MAX_UDP_POINTS * 3];
    int packet_num;
    int mode;
    int frame_number;

    UNITY_UDP_PACKET() : packet_num(0) { }
  } packet_obj;

  // Convert struct to byte stream and send to unity
  auto send_udp_packet = [&]() {
    socket.send_to(boost::asio::buffer(&packet_obj, sizeof packet_obj), endpoint);
    packet_obj.packet_num += 1;
    std::this_thread::sleep_for(std::chrono::microseconds(300));
  };

  // Point cloud done so publish to unity
  using point_cloud_callback_t = const boost::shared_ptr<const sensor_msgs::PointCloud2>;
  auto point_cloud_done = [&](point_cloud_callback_t& msg) {
    pcl::PointCloud<pcl::PointXYZ> cloud;
    pcl::fromROSMsg(*msg, cloud);

    int count = 0;
    int index = 0;

    // Set frame #
    packet_obj.frame_number = frame_counter;

    for(std::size_t i = 0; i < cloud.size(); ++i, ++count) {

      packet_obj.mode = cloud.size() == NUM_POINTS_10HZ_FRAME ? 1 : 0;

      // Send max_points per packet
      if (count % UNITY_MAX_UDP_POINTS == 0 && count > 0) {
        send_udp_packet();

        count = 0;
        ++index;
      }

      // Overwrite array
      packet_obj.points[count*3 + 0] = cloud.points[i].x;
      packet_obj.points[count*3 + 1] = cloud.points[i].y;
      packet_obj.points[count*3 + 2] = cloud.points[i].z;
    }

    // Fill last packet with negative values to avoid garbage
    while (count % UNITY_MAX_UDP_POINTS != 0) {
      packet_obj.points[count*3 + 0] = 0;
      packet_obj.points[count*3 + 1] = 0;
      packet_obj.points[count*3 + 2] = 0;

      ++count;
    }

    // Send the last packet and reset vars
    send_udp_packet();
    packet_obj.packet_num = 0;
    frame_counter += 1;
  };

  // No feedback vs. feedback callbacks
  boost::function<void(point_cloud_callback_t&, unsigned int, unsigned int)> point_cloud_callback = [&](
    point_cloud_callback_t& msg,
    unsigned int topic_edge_index,
    unsigned int topic_return_index
  ) {
    bool rising_edge = true;
    int return_index = 0;
    unsigned int edge_index;

    // Get params
    ros::param::getCached("lv_rising_edge", rising_edge);
    ros::param::getCached("lv_return_index", return_index);
    edge_index = rising_edge ? 0 : 1;

    if (topic_edge_index == edge_index && topic_return_index == return_index) {
      point_cloud_done(msg);
    }
  };

  // Setup subscribers
  ros::Subscriber point_cloud_subscribers[NUM_EDGES][MAX_RETURNS];
  for (unsigned int return_index = 0; return_index < MAX_RETURNS; return_index++) {
    for (unsigned int edge_index = 0; edge_index < NUM_EDGES; edge_index++) {
      const std::string topic_name = "/luminar/point_cloud/" + std::to_string(return_index) + "/" +
                                     (edge_index == 0 ? "rising" : "falling");
      point_cloud_subscribers[edge_index][return_index] = nh.subscribe<sensor_msgs::PointCloud2>
        (topic_name, 10, boost::bind(point_cloud_callback, _1, edge_index, return_index));
    }
  }

  ros::spin();
}
