//
//
// lum_packet_format.c
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#include <assert.h>
#include <netinet/ip.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <sys/time.h>
#include <errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "lum_packet_format.h"

lum_heartbeat_packet lum_multi_return_heartbeat_packet() {
  lum_heartbeat_packet sp = {0};
  sp.magic_number_long = LUM_MAGIC_NUMBER;
  sp.packet_type = LUM_MULTI_DISTANCE_PACKET_TYPE;
  return sp;
}

LUM_ADDRESS_PACKET lum_make_address_packet(uint32_t new_ip_address) {
  LUM_ADDRESS_PACKET packet;
  memset(&packet, 0, sizeof(LUM_ADDRESS_PACKET));
  packet.magic_number_long = LUM_MAGIC_NUMBER;
  packet.packet_type = ADDRESS_PACKET_TYPE;
  packet.new_ip_address = new_ip_address;
  return packet;
}

// There is a lot of code duplication between these next two
// functions.
void lum_transmit_address_packet(LUM_ADDRESS_PACKET packet,
                                 uint32_t lidar_ip_address) {
  int sock = socket(AF_INET, SOCK_DGRAM, 0);
  struct sockaddr_in s;
  memset(&s, 0, sizeof(struct sockaddr_in));
  s.sin_family = AF_INET;
  s.sin_port = (in_port_t)htons(LUM_LIDAR_PORT);
  s.sin_addr.s_addr = htonl(lidar_ip_address);

  if(sendto(sock, &packet, sizeof packet, 0, (struct sockaddr *)&s,
            sizeof(struct sockaddr_in)) < 0) {
    perror("Error transmitting LUM_ADDRESS_PACKET");
  }
}

void lum_broadcast_address_packet(LUM_ADDRESS_PACKET packet) {
  int sock;
  if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
    perror("Error getting socket");
    return;
  }
  int broadcast_enable = 1;
  if (setsockopt(sock, SOL_SOCKET, SO_BROADCAST,
                 &broadcast_enable, sizeof broadcast_enable) < 0) {
    perror("Error setting socket to broadcast.");
  }

  struct sockaddr_in s;
  memset(&s, 0, sizeof(struct sockaddr_in));
  s.sin_family = AF_INET;
  s.sin_port = (in_port_t)htons(LUM_LIDAR_PORT);
  s.sin_addr.s_addr = htonl(INADDR_BROADCAST);

  if(sendto(sock, &packet, sizeof packet, 0, (struct sockaddr *)&s,
            sizeof(struct sockaddr_in)) < 0) {
    perror("Error broadcasting LUM_ADDRESS_PACKET");
  }
}

lum_timestamp_packet lum_make_timestamp_packet(uint32_t sequence) {
  lum_timestamp_packet packet;
  memset(&packet, 0, sizeof(packet));
  packet.sequence = sequence;
  packet.packet_type = PACKET_TIMESTAMP;
  packet.magic_number_long = LUM_MAGIC_NUMBER;
  packet.timestamp = 100;
  //magic number settings
  return packet;
}


bool lum_timestamp_send_and_receive(uint32_t lidar_ip_address,
                                    uint32_t sequence,
                                    uint32_t *returned_timestamp) {
  lum_timestamp_packet packet_data;
  packet_data = lum_make_timestamp_packet(sequence);
  struct sockaddr_in remaddr;
  struct sockaddr_in  recv_addr;
  socklen_t len = sizeof recv_addr;
  memset(&remaddr, 0, sizeof(struct sockaddr_in));
  memset(&recv_addr, 0, sizeof(struct sockaddr_in));
  remaddr.sin_family = AF_INET;
  remaddr.sin_port = (in_port_t)htons(LUM_LIDAR_PORT);
  remaddr.sin_addr.s_addr = htonl(lidar_ip_address);
  int sock;

  if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) < 0){
    //error
    printf("Error creating socket LUM_ADDRESS_PACKET");
    return false;
  }
  //send the request for a timestamp
  if(sendto(sock, &packet_data, sizeof packet_data,
      0, (struct sockaddr *)&remaddr,sizeof remaddr)< 0){
    printf("Error sending timestamp to socket");
    return false;
  }

  //set a timeout for the socket
  struct timeval tv;
  tv.tv_sec = 0;
  tv.tv_usec = 200000;
  if (setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO,&tv,sizeof(tv)) < 0) {
      printf("Timeout Error");
      return false;
  }
  //receive the timestamp data
  ssize_t recvlen = 0;
  recvlen = recvfrom(sock, &packet_data, sizeof(packet_data),
      0, (struct sockaddr *) &recv_addr, &len);

  //check data is correct;
  if (recvlen != 20){
    printf("\nreturned %ld, %d\n",recvlen,errno);
    printf("Error receving timestamp to socket");
    return false;
  }

  if (packet_data.sequence != sequence)
  {
    printf("Received wrong timestamp packet");
    return false;
  }
  *returned_timestamp = packet_data.timestamp;
  return true;
}

size_t lum_group_packet_size(const lum_group_packet *packet) {
  size_t size = LUM_GROUP_HEADER_SIZE;
  if (packet->hdr.tag == LUM_HDR_TAG_ADC) {
    size += packet->hdr.num_samples * sizeof(LUM_ANGLE_PAYLOAD);
  } else {
    size += packet->hdr.num_samples * sizeof(int32_t);
  }
  return size;
}
