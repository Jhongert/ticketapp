//
//
// fpga_client3.cpp
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#include <memory>
#include <stdexcept>
#include <sstream>
#include <algorithm>

#include "fpga_client3.hpp"

namespace lum {

  FpgaClient3::FpgaClient3(uint16_t fpga_port,
                           boost::asio::ip::address_v4 fpga_ip_address,
                           frame_complete_callback_t callback,
                           long heartbeat_period_ms,
                           uint16_t points_per_line,
                           uint16_t num_horizontal_lines,
                           std::vector<uint8_t> return_indices) :
    heartbeat_period_ms_(heartbeat_period_ms),
    io_service_(),
    heartbeat_timer_(io_service_, boost::posix_time::milliseconds(heartbeat_period_ms_)),
    socket_(io_service_, udp::v4()),
    fpga_endpoint_(fpga_ip_address, fpga_port),
    receive_endpoint_(),
    return_indices_(return_indices),
    points_per_line_(points_per_line),
    num_horizontal_lines_(num_horizontal_lines),
    callback_(callback),
    have_last_blue_tof_packet_(false),
    have_last_blue_angle_packet_(false),
    have_last_green_tof_packet_(false),
    have_last_green_angle_packet_(false),
    current_packet_(nullptr) {
    assert(return_indices.size() < MAX_NUM_RETURNS);

    current_packet_ = (lum_group_packet*) malloc(LUM_GROUP_MAX_SIZE);

    // Allocate our buffers
    // h * w * n * e
    auto extents = boost::extents[num_horizontal_lines_][points_per_line_]
                                 [num_returns()][NUM_EDGES_PER_RETURN];
    raw_returns_t green_returns(extents);
    raw_returns_t blue_returns(extents);
    eye_to_returns_.emplace(LUM_GREEN_EYE, green_returns);
    eye_to_returns_.emplace(LUM_BLUE_EYE, blue_returns);

    // h * w
    auto angle_extents = boost::extents[num_horizontal_lines_][points_per_line_];
    raw_angles_t green_azimuths(angle_extents);
    raw_angles_t blue_azimuths(angle_extents);
    eye_to_azimuths_.emplace(LUM_GREEN_EYE, green_azimuths);
    eye_to_azimuths_.emplace(LUM_BLUE_EYE, blue_azimuths);

    raw_angles_t green_elevations(angle_extents);
    raw_angles_t blue_elevations(angle_extents);
    eye_to_elevations_.emplace(LUM_GREEN_EYE, green_elevations);
    eye_to_elevations_.emplace(LUM_BLUE_EYE, blue_elevations);


    // NOTE(Daniel): I don't think we need to do this.
    int disabled = 1;
    if (setsockopt(socket_.native(), SOL_SOCKET, SO_NO_CHECK, &disabled, sizeof disabled) < 0) {
      throw std::logic_error("Problem disabling UDP checksum checking!");
    }
  }

  FpgaClient3::~FpgaClient3() {
    free(current_packet_);
  }

  void FpgaClient3::start() {
    send_heartbeat_packet();
    setup_receive();
    io_service_.run();
  }

  void FpgaClient3::set_fpga_ip_address(const std::string& ip) {
    boost::asio::ip::address_v4 fpga_new_ip_address = boost::asio::ip::address_v4::from_string(ip);

    uint32_t new_ip_num = static_cast<uint32_t>(fpga_new_ip_address.to_ulong());
    uint32_t current_fpga_ip_num = static_cast<uint32_t>(fpga_endpoint_.address().to_v4().to_ulong());

    LUM_ADDRESS_PACKET addr_packet = lum_make_address_packet(new_ip_num);
    lum_transmit_address_packet(addr_packet, current_fpga_ip_num);

    fpga_endpoint_.address(fpga_new_ip_address);
  }

  void FpgaClient3::send_heartbeat_packet() {
    lum_heartbeat_packet heartbeat = lum_multi_return_heartbeat_packet();
    socket_.send_to(boost::asio::buffer((void*)&heartbeat, sizeof heartbeat),
                    fpga_endpoint_);
    heartbeat_timer_.expires_at(heartbeat_timer_.expires_at() +
                                boost::posix_time::milliseconds(heartbeat_period_ms_));
    heartbeat_timer_.async_wait(boost::bind(&FpgaClient3::send_heartbeat_packet,
                                            this));
  }

  void FpgaClient3::set_num_horizontal_lines(uint16_t num_lines) {
    mutex_.lock();
    num_horizontal_lines_ = num_lines;

    auto extents = boost::extents[num_horizontal_lines_][points_per_line_]
                                 [num_returns()][NUM_EDGES_PER_RETURN];
    eye_to_returns_[LUM_LEFT_EYE].resize(extents);
    eye_to_returns_[LUM_RIGHT_EYE].resize(extents);

    auto angle_extents = boost::extents[num_horizontal_lines_][points_per_line_];
    eye_to_azimuths_[LUM_LEFT_EYE].resize(angle_extents);
    eye_to_azimuths_[LUM_RIGHT_EYE].resize(angle_extents);
    eye_to_elevations_[LUM_LEFT_EYE].resize(angle_extents);
    eye_to_elevations_[LUM_RIGHT_EYE].resize(angle_extents);
    mutex_.unlock();
  }

  void FpgaClient3::set_return_indices(std::vector<uint8_t> return_indices) {
    assert(return_indices.size() < MAX_NUM_RETURNS);
    mutex_.lock();
    return_indices_ = return_indices;

    auto extents = boost::extents[num_horizontal_lines_][points_per_line_]
                                 [num_returns()][NUM_EDGES_PER_RETURN];
    eye_to_returns_[LUM_LEFT_EYE].resize(extents);
    eye_to_returns_[LUM_RIGHT_EYE].resize(extents);
    mutex_.unlock();
  }

  void FpgaClient3::setup_receive() {
    socket_.async_receive_from(
            boost::asio::buffer(current_packet_, LUM_GROUP_MAX_SIZE),
            receive_endpoint_,
            boost::bind(&FpgaClient3::handle_receive_from, this,
                        boost::asio::placeholders::error,
                        boost::asio::placeholders::bytes_transferred));
  }

  void FpgaClient3::handle_receive_from(const boost::system::error_code& error,
                                        std::size_t bytes_recvd) {
    if (!error && bytes_recvd > 0) {
      // Start validating packet
      if (fpga_endpoint_.address() != receive_endpoint_.address()) {
        // receive_endpoint_ address should be set to source of this
        // packet, since it was passed by reference to
        // socket_.async_receive_from()
        std::stringstream str_builder;
        str_builder << "Received data from " << receive_endpoint_ << ", but expected data from: "
                    << fpga_endpoint_;
        throw std::runtime_error(str_builder.str());
      }

      if (current_packet_->hdr.line >= num_horizontal_lines_) {
        std::cout << "WARNING: Received a line number too large! " <<
          current_packet_->hdr.line << std::endl;
        setup_receive();
        return;
      }

      if (current_packet_->hdr.tag != LUM_HDR_TAG_ADC &&
          current_packet_->hdr.tag != LUM_HDR_TAG_RANGE) {
        std::stringstream str_builder;
        std::cout <<  "Received invalid packet tag: " << current_packet_->hdr.tag <<
          ". Is the LIDAR sending the legacy data format?" << std::endl;
        setup_receive();
        return;
      }

      // Finish validating packet

      const uint8_t eye_and_edge = current_packet_->hdr.eye;
      if (! (eye_and_edge == LUM_EYE_GREEN_RISE || eye_and_edge == LUM_EYE_BLUE_RISE ||
             eye_and_edge == LUM_EYE_GREEN_DROP || eye_and_edge == LUM_EYE_BLUE_DROP)) {
        std::stringstream str_builder;
        str_builder << "Unknown packet eye_edge index " << eye_and_edge;
        throw std::runtime_error(str_builder.str());
      }
      const uint8_t eye = (current_packet_->hdr.eye & EYE_BLUE_FLAG) ? LUM_BLUE_EYE : LUM_GREEN_EYE;

      // Start copying packet's payload
      mutex_.lock();
      if (current_packet_->hdr.tag == LUM_HDR_TAG_ADC) {
        LUM_ANGLE_PAYLOAD *samples = (LUM_ANGLE_PAYLOAD*)(&current_packet_->payload[0]);
        for (unsigned int i = 0; i < current_packet_->hdr.num_samples; i++) {
          std::size_t index_in_line = (current_packet_->hdr.line % 2 == 0) ?
            current_packet_->hdr.first_sample_index + i :
            points_per_line_ - 1 - (current_packet_->hdr.first_sample_index + i);
          LUM_ANGLE_PAYLOAD angle_pair = samples[i];
          eye_to_azimuths_[eye][current_packet_->hdr.line][index_in_line] = angle_pair.azimuth;
          eye_to_elevations_[eye][current_packet_->hdr.line][index_in_line] = angle_pair.elevation;
        }

        bool is_last_sample = (current_packet_->hdr.line == num_horizontal_lines_ - 1 &&
                               current_packet_->hdr.first_sample_index + current_packet_->hdr.num_samples
                               == points_per_line_);
        if (eye == LUM_GREEN_EYE) {
          have_last_green_angle_packet_ = is_last_sample;
        } else {
          have_last_blue_angle_packet_ = is_last_sample;
        }
      } else { // we must have received distance data
        int32_t *tof_samples = (int32_t*)(&current_packet_->payload[0]);

        // See comment below about MAX_POINTS_PER_HORIZONTAL_LINE + 1 sentinel.
        uint16_t previous_index_in_line = MAX_POINTS_PER_HORIZONTAL_LINE + 1;
        std::size_t num_ranges_for_this_line_index_received_so_far = 0;
        bool is_last_sample = false;

        for (unsigned int i = 0; i < current_packet_->hdr.num_samples; i++) {
          int32_t tof_return = tof_samples[i];
          float tof; uint16_t index_in_line;
          unpack_sample(tof_return, &tof, &index_in_line);
          if (index_in_line > 1000)
          {
              std::cerr << "index in line greater than 1000 straight from packet, val = " << index_in_line << std::endl;
	      break;
          }
          index_in_line = std::min(999, (int)index_in_line);

          index_in_line = (current_packet_->hdr.line % 2 == 0) ? index_in_line
                          : points_per_line_ - 1 - index_in_line;

          // Slightly confusing: 1 corresponds to rising edge in UDP
          // packets coming from FPGA, but afterwards index 0
          // corresponds to rising edge in the boost::multi_array
          // I chose index 0 to correspond to rising edge because it comes
          // before the falling edge physically in time.
          // (static_cast<> makes this change. See "enum class EventEdge").
          EventEdge edge = (current_packet_->hdr.eye & EYE_RISE_FLAG) ?
                           EventEdge::Rising : EventEdge::Falling;
          uint8_t edge_index = static_cast<uint8_t>(edge);

          // Use MAX_POINTS_PER_HORIZONTAL_LINE + 1 sentinel value so we don't
          // always overwrite the first point of each line
          // unintentionally
          if (index_in_line != previous_index_in_line &&
              previous_index_in_line != MAX_POINTS_PER_HORIZONTAL_LINE + 1) {
            // 1) Fill the returns not received with the value
            // MISSING_RETURN for the previous_index_in_line
            for(; num_ranges_for_this_line_index_received_so_far < num_returns();
                num_ranges_for_this_line_index_received_so_far++) {
              eye_to_returns_[eye][current_packet_->hdr.line][previous_index_in_line]
                [num_ranges_for_this_line_index_received_so_far][edge_index] = MISSING_RETURN;
            }
            // 2) Reset number of returns received for index_in_line.
            num_ranges_for_this_line_index_received_so_far = 0;
          }

          if (num_ranges_for_this_line_index_received_so_far < num_returns()) {
            eye_to_returns_[eye][current_packet_->hdr.line][index_in_line]
                           [num_ranges_for_this_line_index_received_so_far]
                           [edge_index] = tof;
          }

          previous_index_in_line = index_in_line;
          num_ranges_for_this_line_index_received_so_far++;

          // This may be a little bit premature, since their may be more
          // than one return for the last index in a line, but those
          // returns are guaranteed to be in the same UDP packet, so it's okay.
          is_last_sample = (index_in_line == MAX_POINTS_PER_HORIZONTAL_LINE - 1
                            && current_packet_->hdr.line == num_horizontal_lines_ - 1);
        }

        if (eye == LUM_GREEN_EYE) {
          have_last_green_tof_packet_ = is_last_sample;
        } else {
          have_last_blue_tof_packet_ = is_last_sample;
        }
      }
      mutex_.unlock();

      if (have_last_blue_angle_packet_ && have_last_green_angle_packet_) {
        have_last_blue_tof_packet_ = false;
        have_last_blue_angle_packet_ = false;
        have_last_green_tof_packet_ = false;
        have_last_green_angle_packet_ = false;
        bool should_stop = callback_(eye_to_returns_, eye_to_azimuths_,
                                     eye_to_elevations_, return_indices_);
        if (should_stop) {
          io_service_.stop();
        }
      }
    } else {
      std::stringstream str_builder;
      str_builder << "Received UDP packet was " << bytes_recvd <<
        " bytes long and had this error: " << error;
      throw std::runtime_error(str_builder.str());
    }
    setup_receive();
  }
}
