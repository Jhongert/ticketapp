//
//
// lumsdk_point_cloud_node.cpp
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#include <fstream>
#include <thread>
#include <unordered_map>

#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>

#include <ros/ros.h>
#include <sensor_msgs/PointCloud2.h>
#include <std_msgs/Float32MultiArray.h>
#include <std_msgs/String.h>
#include <std_msgs/Bool.h>

#include <luminar_point_cloud/LumEyeData.h>

#include "point_types.hpp"
#include "conversions.hpp"
#include "lum_calibration_params.hpp"
#include "lum_packet_format.h"

#define MAX_RETURNS 8
#define NUM_EDGES 2
#define INVALID_POINT_VALUE -100

using namespace lum;

// If we need to mutate the data, make a new function that calls
// this one and then uses a const_cast
boost::const_multi_array_ref<int16_t, 2> boost_multi_array_of_ros_multi_array(
  const std_msgs::Int16MultiArray &msg) {
  auto extents = boost::extents[msg.layout.dim[0].size][msg.layout.dim[1].size];
  return boost::const_multi_array_ref<int16_t, 2>(msg.data.data(), extents);
}

boost::const_multi_array_ref<float, 4> boost_multi_array_of_ros_multi_array(
  const std_msgs::Float32MultiArray &msg) {
  auto extents = boost::extents[msg.layout.dim[0].size][msg.layout.dim[1].size]
                               [msg.layout.dim[2].size][msg.layout.dim[3].size];
  return boost::const_multi_array_ref<float, 4>(msg.data.data(), extents);
}

void get_disc_params(const std::vector<int16_t>& elevations,
                     const std::vector<int16_t>& azimuths,
                     int16_t *elevation_disc_min_ret, int16_t *elevation_disc_max_ret,
                     int16_t *azimuth_disc_min_ret, int16_t *azimuth_disc_max_ret) {
  unsigned int order_statistic = 5;
  std::vector<int16_t> partial_sort_copy_scratch_space(order_statistic + 1);
  // Super ugly unrolled loop!
  std::partial_sort_copy(elevations.cbegin(),
                         elevations.cend(),
                         partial_sort_copy_scratch_space.begin(),
                         partial_sort_copy_scratch_space.end());
  *elevation_disc_min_ret = partial_sort_copy_scratch_space[order_statistic];
  std::partial_sort_copy(elevations.cbegin(),
                         elevations.cend(),
                         partial_sort_copy_scratch_space.begin(),
                         partial_sort_copy_scratch_space.end(),
                         std::greater<int16_t>());
  *elevation_disc_max_ret = partial_sort_copy_scratch_space[order_statistic];
  assert(*elevation_disc_max_ret >= *elevation_disc_min_ret);

  std::partial_sort_copy(azimuths.cbegin(), azimuths.cend(),
                         partial_sort_copy_scratch_space.begin(),
                         partial_sort_copy_scratch_space.end());
  *azimuth_disc_min_ret = partial_sort_copy_scratch_space[order_statistic];
  std::partial_sort_copy(azimuths.cbegin(), azimuths.cend(),
                         partial_sort_copy_scratch_space.begin(),
                         partial_sort_copy_scratch_space.end(),
                         std::greater<int16_t>());
  *azimuth_disc_max_ret = partial_sort_copy_scratch_space[order_statistic];

  assert(*azimuth_disc_max_ret >= *azimuth_disc_min_ret);
}

int main(int argc, char **argv) {
  // Ros variables
  ros::init(argc, argv, "lumsdk_point_cloud_node");
  ros::start();
  ros::NodeHandle nh;

  unsigned int count[NUM_EDGES][MAX_RETURNS] = {0};
  bool green_ready[NUM_EDGES][MAX_RETURNS] = {0};
  bool blue_ready[NUM_EDGES][MAX_RETURNS] = {0};

  // Smoothed angle values
  std::unordered_map<lum_eye_t, std::vector<float>> smooth_azimuths;
  smooth_azimuths.emplace(LUM_GREEN_EYE, std::vector<float>{});
  smooth_azimuths.emplace(LUM_BLUE_EYE, std::vector<float>{});

  std::unordered_map<lum_eye_t, std::vector<float>> smooth_elevations;
  smooth_elevations.emplace(LUM_GREEN_EYE, std::vector<float>{});
  smooth_elevations.emplace(LUM_BLUE_EYE, std::vector<float>{});

  // This gets set to a positive value when we need to invalidate our
  // current averaged estimates for elevation data (probably because a
  // new y scan pattern was requested).
  unsigned int dont_smooth_count = 0;

  // Publish topics (raw data + point cloud)
  ros::Publisher point_cloud_publishers[NUM_EDGES][MAX_RETURNS];
  pcl::PointCloud<pcl::PointXYZI>::Ptr full_clouds[NUM_EDGES][MAX_RETURNS];

  for (unsigned int i = 0; i < MAX_RETURNS; ++i) {
    for (unsigned int edge_index = 0; edge_index < NUM_EDGES; edge_index++) {
      const std::string topic_name = "/luminar/point_cloud/" + std::to_string(i) + "/" +
                                     (edge_index == 0 ? "rising" : "falling");
      point_cloud_publishers[edge_index][i] = nh.advertise<sensor_msgs::PointCloud2>(topic_name, 2);
      full_clouds[edge_index][i] = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
    }
  }

  // Callback for when both eyes ready
  auto publish_when_ready = [&](unsigned int edge_index,
                                unsigned int cloud_index) {
    if (!green_ready[edge_index][cloud_index] ||
        !blue_ready[edge_index][cloud_index]) {
      return;
    }

    // Publish the full point cloud for everyone else
    sensor_msgs::PointCloud2 cloud_msg;
    pcl::toROSMsg(*(full_clouds[edge_index][cloud_index]), cloud_msg);
    cloud_msg.header.seq = count[edge_index][cloud_index];
    cloud_msg.header.stamp = ros::Time::now();
    cloud_msg.header.frame_id = "/lum";
    point_cloud_publishers[edge_index][cloud_index].publish(cloud_msg);

    // Reset ready markers
    green_ready[edge_index][cloud_index] = false;
    blue_ready[edge_index][cloud_index] = false;

    ++count[edge_index][cloud_index];
  };

  // Main callback when a raw eye is published from FPGA
  using raw_data_callback_t = const boost::shared_ptr<const luminar_point_cloud::LumEyeData>;
  boost::function<void(raw_data_callback_t&)> raw_data_callback = [&](raw_data_callback_t& msg) {
    // Init variables to process current eye
    const lum_eye_t &eye = msg->eye.data;

    const std::vector<uint8_t> return_indices = msg->return_indices.data;
    const std::size_t num_returns = return_indices.size();
    assert(num_returns < MAX_RETURNS);

    // Get the min and max discrete angle values so we can map them to
    // angle values in degrees
    int16_t elevation_disc_min, elevation_disc_max, azimuth_disc_min,
            azimuth_disc_max;
    get_disc_params(msg->elevation.data, msg->azimuth.data,
                    &elevation_disc_min, &elevation_disc_max,
                    &azimuth_disc_min, &azimuth_disc_max);

    // Get appropriate parameters for calibration
    float range_offset, highest_altitude_degrees, lowest_altitude_degrees,
          azimuth_center_degrees, azimuth_width_degrees;
    bool should_flip;
    int phase_shift;

    // Stop if params are missing
    if(eye == LUM_GREEN_EYE) {
      if(!ros::param::getCached(lum::GREEN_RANGE_OFFSET_PARAM, range_offset) ||
         !ros::param::getCached(lum::GREEN_HIGHEST_ALTITUDE_DEGREES_PARAM, highest_altitude_degrees) ||
         !ros::param::getCached(lum::GREEN_LOWEST_ALTITUDE_DEGREES_PARAM, lowest_altitude_degrees) ||
         !ros::param::getCached(lum::GREEN_AZIMUTH_CENTER_DEGREES_PARAM, azimuth_center_degrees) ||
         !ros::param::getCached(lum::GREEN_AZIMUTH_WIDTH_DEGREES_PARAM, azimuth_width_degrees) ||
         !ros::param::getCached(lum::GREEN_FLIP_PARAM, should_flip) ||
         !ros::param::getCached(lum::GREEN_PHASE_SHIFT_PARAM, phase_shift)) {
        ROS_ERROR("No value set for some GREEN eye calibration parameters");
      }
    } else { // blue eye
      if(!ros::param::getCached(lum::BLUE_RANGE_OFFSET_PARAM, range_offset) ||
         !ros::param::getCached(lum::BLUE_HIGHEST_ALTITUDE_DEGREES_PARAM, highest_altitude_degrees) ||
         !ros::param::getCached(lum::BLUE_LOWEST_ALTITUDE_DEGREES_PARAM, lowest_altitude_degrees) ||
         !ros::param::getCached(lum::BLUE_AZIMUTH_CENTER_DEGREES_PARAM, azimuth_center_degrees) ||
         !ros::param::getCached(lum::BLUE_AZIMUTH_WIDTH_DEGREES_PARAM, azimuth_width_degrees) ||
         !ros::param::getCached(lum::BLUE_FLIP_PARAM, should_flip) ||
         !ros::param::getCached(lum::BLUE_PHASE_SHIFT_PARAM, phase_shift)) {
        ROS_ERROR("No value set for some BLUE eye calibration parameters");
      }
    }

    // Get LuminView related params
    bool do_noise_filtering;
    int point_threshold;
    double distance_threshold;
    float t0_distance_cutoff;
    bool smooth_angle_data;

    // Stop if any of them are missing
    if (!ros::param::getCached("lv_noise_filtering", do_noise_filtering) ||
        !ros::param::getCached("lv_noise_point_threshold", point_threshold) ||
        !ros::param::getCached("lv_noise_distance_threshold", distance_threshold) ||
        !ros::param::getCached("t0_distance_cutoff", t0_distance_cutoff) ||
        !ros::param::getCached("lv_smooth_angle_data", smooth_angle_data)) {
      ROS_ERROR("No value set for LuminView related parameters");
      return;
    }

    boost::const_multi_array_ref<int16_t, 2> azimuths =
                             boost_multi_array_of_ros_multi_array(msg->azimuth);
    boost::const_multi_array_ref<int16_t, 2> elevations =
                             boost_multi_array_of_ros_multi_array(msg->elevation);
    boost::const_multi_array_ref<float, 4> returns =
                             boost_multi_array_of_ros_multi_array(msg->returns);

    unsigned int num_lines = returns.shape()[0];
    unsigned int points_per_line = returns.shape()[1];
    unsigned int points_per_frame = num_lines * points_per_line;

    if (smooth_azimuths.at(eye).size() != points_per_frame) {
      smooth_azimuths.at(eye).resize(points_per_frame);
      std::copy(msg->azimuth.data.cbegin(), msg->azimuth.data.cend(),
                smooth_azimuths.at(eye).begin());
    } else {
      const float window = 50;
      for(unsigned int i = 0; i < msg->azimuth.data.size(); i++) {
        unsigned int line = i / points_per_line;
        unsigned int index_in_line = i % points_per_line;

        float average = smooth_azimuths.at(eye)[i];
        float new_value = azimuths[line][index_in_line];
        average -= average / window;
        average += new_value / window;
        smooth_azimuths.at(eye)[i] = average;
      }
    }

    if (smooth_elevations[eye].size() != points_per_frame ||
        dont_smooth_count > 0) {
      smooth_elevations[eye].resize(msg->elevation.data.size());
      std::copy(msg->elevation.data.cbegin(), msg->elevation.data.cend(),
                smooth_elevations[eye].begin());
    } else {
      const float window = 10;
      for(unsigned int i = 0; i < smooth_elevations.at(eye).size(); i++) {
        unsigned int line = i / points_per_line;
        unsigned int index_in_line = i % points_per_line;

        float average = smooth_elevations.at(eye)[i];
        float new_value = elevations[line][index_in_line];
        average -= average / window;
        average += new_value / window;
        smooth_elevations.at(eye)[i] = average;
      }
    }

    if (dont_smooth_count > 0) {
      dont_smooth_count--;
    }

    // Actually publish the point clouds!
    // Note: this is not 100% cache-efficient. Oh, well.
    for (std::size_t return_index = 0; return_index < num_returns; return_index++) {
      for (unsigned int edge_index = 0; edge_index < NUM_EDGES; edge_index++) {
        auto &full_cloud = full_clouds[edge_index][return_index];

        // Resize our global cloud if needed
        if (full_cloud->size() != 2 * returns.shape()[0] * returns.shape()[1]) {
          //  multiply by 2 because we have two eyes!
          full_cloud->resize(2 * returns.shape()[0] * returns.shape()[1]);

          // If the cloud size has changed, this indicates a Hz
          // transition (not currently supported), which can cause encoder values of 0 to creep in
          // from the FpgaClient3 (e.g., a UDP packet is missed). Reduce
          // the possibility of this messing up averaging by refusing to
          // average for at least 4 frames of data.
          dont_smooth_count += 8;
        }

        unsigned int point_cloud_index = 0;

        for (unsigned int row_index = 0; row_index < num_lines; row_index++) {
          for (unsigned int col_index = 0; col_index < points_per_line; col_index++) {
            float azimuth, elevation;

            if (smooth_angle_data) {
              azimuth = smooth_azimuths.at(eye)[point_cloud_index];
              elevation = smooth_elevations.at(eye)[point_cloud_index];
            } else {
              azimuth   = azimuths[row_index][col_index];
              elevation = elevations[row_index][col_index];
            }

            float distance  = returns[row_index][col_index][return_index][edge_index];

            // for green eye, skip rescan: first line
            // for blue eye, skip rescan: last line
            if ((eye == LUM_GREEN_EYE && row_index == 0) ||
                (eye == LUM_BLUE_EYE && row_index == num_lines - 1)) {
              pcl::PointXYZI pcl_point;
              pcl_point.x = INVALID_POINT_VALUE;
              pcl_point.y = INVALID_POINT_VALUE;
              pcl_point.z = INVALID_POINT_VALUE;
              pcl_point.intensity = 0;

              if (eye == LUM_BLUE_EYE) {
                (*full_cloud)[point_cloud_index] = pcl_point;
              } else {
                (*full_cloud)[point_cloud_index + full_cloud->size() / 2] = pcl_point;
              }

              point_cloud_index++;
              continue;
            }

            // Do spherical conversion
            float azimuth_degrees = azimuth_deg_of_disc_azimuth(-azimuth, azimuth_width_degrees,
                                                                azimuth_disc_min, azimuth_disc_max);
            azimuth_degrees += azimuth_center_degrees;

            float raw_elevation_value = should_flip ? elevation : -elevation;
            float elevation_degrees =
              elevation_deg_of_disc_elevation(raw_elevation_value,
                                              lowest_altitude_degrees,
                                              highest_altitude_degrees,
                                              elevation_disc_min, elevation_disc_max);

            float distance_meters = meter_of_disc_distance(distance, range_offset);

            // Remove < T0 points according to rosparam
            if (distance_meters < t0_distance_cutoff) {
              pcl::PointXYZI pcl_point;
              pcl_point.x = INVALID_POINT_VALUE;
              pcl_point.y = INVALID_POINT_VALUE;
              pcl_point.z = INVALID_POINT_VALUE;
              pcl_point.intensity = 0;

              if (eye == LUM_BLUE_EYE) {
                (*full_cloud)[point_cloud_index] = pcl_point;
              } else {
                (*full_cloud)[point_cloud_index + full_cloud->size() / 2] = pcl_point;
              }

              point_cloud_index++;
              continue;
            }

            // Create point cloud point
            lum::PointXYZ cartesian_point = spherical(azimuth_degrees, 90.0 - elevation_degrees, distance_meters);

            pcl::PointXYZI pcl_point;
            pcl_point.x = cartesian_point.x;
            pcl_point.y = cartesian_point.y;
            pcl_point.z = cartesian_point.z;
            pcl_point.intensity = distance_meters;

            // Do noise filtering if enabled
            if (do_noise_filtering) {
              // Find all neighbor depth values

              float right = 0.0,
                    left = 0.0,
                    top = 0.0,
                    bottom = 0.0,
                    top_right = 0.0,
                    top_left = 0.0,
                    bottom_right = 0.0,
                    bottom_left = 0.0;

              if (col_index < points_per_line - 1) {
                right = meter_of_disc_distance(
                  returns[row_index][col_index + 1][return_index][edge_index], range_offset);
              }

              if (col_index > 0) {
                left = meter_of_disc_distance(
                  returns[row_index][col_index - 1][return_index][edge_index], range_offset);
              }

              if (row_index > 0) {
                top = meter_of_disc_distance(
                  returns[row_index - 1][col_index][return_index][edge_index], range_offset);

                if (col_index < points_per_line - 1) {
                  top_right = meter_of_disc_distance(
                    returns[row_index - 1][col_index + 1][return_index][edge_index], range_offset);
                }

                if (col_index > 0) {
                  top_left = meter_of_disc_distance(
                    returns[row_index - 1][col_index - 1][return_index][edge_index], range_offset);
                }
              }

              if (row_index < num_lines - 1) {
                bottom = meter_of_disc_distance(
                  returns[row_index + 1][col_index][return_index][edge_index], range_offset);

                if (col_index < points_per_line - 1) {
                  bottom_right = meter_of_disc_distance(
                    returns[row_index + 1][col_index + 1][return_index][edge_index], range_offset);
                }

                if (col_index > 0) {
                  bottom_left = meter_of_disc_distance(
                    returns[row_index + 1][col_index - 1][return_index][edge_index], range_offset);
                }
              }

              int nok = 0;
              if (fabs(distance_meters - right) < distance_threshold) ++nok;
              if (fabs(distance_meters - left) < distance_threshold) ++nok;
              if (fabs(distance_meters - top) < distance_threshold) ++nok;
              if (fabs(distance_meters - bottom) < distance_threshold) ++nok;
              if (fabs(distance_meters - top_right) < distance_threshold) ++nok;
              if (fabs(distance_meters - top_left) < distance_threshold) ++nok;
              if (fabs(distance_meters - bottom_right) < distance_threshold) ++nok;
              if (fabs(distance_meters - bottom_left) < distance_threshold) ++nok;

              // Null point if not enough neighbors
              if (nok < point_threshold) {
                pcl_point.x = INVALID_POINT_VALUE;
                pcl_point.y = INVALID_POINT_VALUE;
                pcl_point.z = INVALID_POINT_VALUE;
                pcl_point.intensity = 0;
              }
            }

            // Update cloud
            if (eye == LUM_BLUE_EYE) {
              (*full_cloud)[point_cloud_index] = pcl_point;
            } else {
              (*full_cloud)[point_cloud_index + full_cloud->size() / 2] = pcl_point;
            }
            point_cloud_index++;
          }
        }

        // Publish if we have both eyes ready
        if (eye == LUM_BLUE_EYE) {
          blue_ready[edge_index][return_index] = true;
        } else {
          green_ready[edge_index][return_index] = true;
        }

        publish_when_ready(edge_index, return_index);
      }
    }
  };

  // Subscribers
  ros::Subscriber sub_raw_green =
    nh.subscribe<luminar_point_cloud::LumEyeData>("/luminar_raw_blue_data", 10, raw_data_callback);

  ros::Subscriber sub_raw_blue =
    nh.subscribe<luminar_point_cloud::LumEyeData>("/luminar_raw_green_data", 10, raw_data_callback);

  // Know when yscan changes to stop angle smoothing for 8 frames
  using bool_callback_t = const boost::shared_ptr<const std_msgs::Bool>;
  boost::function<void(bool_callback_t)> disable_smoothing_callback = [&](bool_callback_t msg) {
    dont_smooth_count = 8;
  };
  ros::Subscriber sub_tlv_command =
    nh.subscribe<std_msgs::Bool>("/luminar_yscan_changed", 10, disable_smoothing_callback);

  ros::spin();
}
