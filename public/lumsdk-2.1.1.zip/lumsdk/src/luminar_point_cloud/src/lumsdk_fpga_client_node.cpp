//
//
// lumsdk_fpga_client_node.cpp
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#include <fstream>
#include <thread>
#include <vector>

#include <boost/multi_array.hpp>

#include <ros/ros.h>
#include <std_msgs/UInt8.h>

#include <luminar_point_cloud/LumEyeData.h>

#include "fpga_client3.hpp"
#include "lum_calibration_params.hpp"
#include "lum_packet_format.h"

#define NUM_EDGES 2

using namespace lum;

int main(int argc, char **argv) {
  boost::asio::ip::address_v4 fpga_ip_address = boost::asio::ip::address_v4(LUM_LIDAR_IP_ADDRESS);

  // ROS variables
  ros::init(argc, argv, "luminar_fpga_client_node");
  ros::start();
  ros::NodeHandle nh;
  unsigned int count = 0;

  // Publishers
  ros::Publisher pub_raw_green = nh.advertise<luminar_point_cloud::LumEyeData>("/luminar_raw_green_data", 2);
  ros::Publisher pub_raw_blue = nh.advertise<luminar_point_cloud::LumEyeData>("/luminar_raw_blue_data", 2);

  // Declare this outside the FPGA callback so that we don't have to
  // keep reallocating its large memory buffers
  luminar_point_cloud::LumEyeData eye_data_msg;
  eye_data_msg.elevation.layout.dim.resize(2, std_msgs::MultiArrayDimension());
  eye_data_msg.azimuth.layout.dim.resize(2, std_msgs::MultiArrayDimension());
  eye_data_msg.returns.layout.dim.resize(4, std_msgs::MultiArrayDimension());
  eye_data_msg.return_indices.layout.dim.resize(1, std_msgs::MultiArrayDimension());

  // FPGA callback
  auto callback = [&](
    const std::unordered_map<lum_eye_t, raw_returns_t>& eye_to_returns,
    const std::unordered_map<lum_eye_t, raw_angles_t>& eye_to_azimuths,
    const std::unordered_map<lum_eye_t, raw_angles_t>& eye_to_elevations,
    const std::vector<uint8_t>& return_indices) {
    std::thread publisher_thread([&]() {
      for (const lum_eye_t &eye : {LUM_BLUE_EYE, LUM_GREEN_EYE}) {
        const raw_returns_t& returns = eye_to_returns.at(eye);
        const raw_angles_t& azimuths = eye_to_azimuths.at(eye);
        const raw_angles_t& elevations = eye_to_elevations.at(eye);

        const std::size_t num_returns = return_indices.size();
        const unsigned int num_lines = returns.shape()[0];
        const unsigned int points_per_line = returns.shape()[1];

        // Create new custom message for each eye
        eye_data_msg.header.stamp = ros::Time::now();
        eye_data_msg.header.frame_id = "/lum";
        eye_data_msg.header.seq = count;
        eye_data_msg.eye.data = eye;

        eye_data_msg.return_indices.data.resize(num_returns);
        eye_data_msg.return_indices.layout.dim[0].size = num_returns;
        eye_data_msg.return_indices.layout.dim[0].stride = 1;
        eye_data_msg.return_indices.layout.data_offset = 0;
        eye_data_msg.return_indices.data = return_indices;

        // Initialize the data structures
        // NOTE(Daniel): .size() == .shape()[0]! Evil boost! Not
        eye_data_msg.elevation.data.resize(elevations.num_elements());
        eye_data_msg.elevation.layout.dim[0].size = elevations.shape()[0];
        eye_data_msg.elevation.layout.dim[0].stride = elevations.shape()[1];
        eye_data_msg.elevation.layout.dim[0].label = "scan_line";
        eye_data_msg.elevation.layout.dim[1].size = elevations.shape()[1];
        eye_data_msg.elevation.layout.dim[1].stride = 1;
        eye_data_msg.elevation.layout.dim[1].label = "point";
        eye_data_msg.elevation.layout.data_offset = 0;

        eye_data_msg.azimuth.data.resize(azimuths.num_elements());
        eye_data_msg.azimuth.layout.dim[0].size = azimuths.shape()[0];
        eye_data_msg.azimuth.layout.dim[0].stride = azimuths.shape()[1];
        eye_data_msg.azimuth.layout.dim[0].label = "scan_line";
        eye_data_msg.azimuth.layout.dim[1].size = azimuths.shape()[1];
        eye_data_msg.azimuth.layout.dim[1].stride = 1;
        eye_data_msg.azimuth.layout.dim[1].label = "point";
        eye_data_msg.azimuth.layout.data_offset = 0;

        eye_data_msg.returns.data.resize(returns.num_elements());
        eye_data_msg.returns.layout.dim[0].size = returns.shape()[0];
        eye_data_msg.returns.layout.dim[0].stride = returns.shape()[1] *
                                                    returns.shape()[2] *
                                                    returns.shape()[3];
        eye_data_msg.returns.layout.dim[0].label = "scan_line";
        eye_data_msg.returns.layout.dim[1].size = returns.shape()[1];
        eye_data_msg.returns.layout.dim[1].stride = returns.shape()[2] * returns.shape()[3];
        eye_data_msg.returns.layout.dim[1].label = "point";
        eye_data_msg.returns.layout.dim[2].size = returns.shape()[2];
        eye_data_msg.returns.layout.dim[2].stride = returns.shape()[3];
        eye_data_msg.returns.layout.dim[2].label = "num_returns";
        eye_data_msg.returns.layout.dim[3].size = returns.shape()[3];
        eye_data_msg.returns.layout.dim[3].stride = 1;
        eye_data_msg.returns.layout.dim[3].label = "num_edges";

        auto az_shape = azimuths.shape();
        auto az_extents = boost::extents[az_shape[0]][az_shape[1]];
        boost::multi_array_ref<int16_t, 2> azimuths_msg(eye_data_msg.azimuth.data.data(), az_extents);
        std::copy(azimuths.data(), azimuths.data() + azimuths.num_elements(), azimuths_msg.origin());

        auto el_shape = elevations.shape();
        auto el_extents = boost::extents[el_shape[0]][el_shape[1]];
        boost::multi_array_ref<int16_t, 2> elevations_msg(eye_data_msg.elevation.data.data(), el_extents);
        std::copy(elevations.data(), elevations.data() + elevations.num_elements(), elevations_msg.origin());

        auto ret_shape = returns.shape();
        auto ret_extents = boost::extents[ret_shape[0]][ret_shape[1]][ret_shape[2]][ret_shape[3]];
        boost::multi_array_ref<float, 4> returns_msg(eye_data_msg.returns.data.data(), ret_extents);
        std::copy(returns.data(), returns.data() + returns.num_elements(), returns_msg.origin());

        bool should_flip;
        const std::string should_flip_param_name =
          (eye == LUM_GREEN_EYE) ? GREEN_FLIP_PARAM : BLUE_FLIP_PARAM;
        if (!ros::param::getCached(should_flip_param_name, should_flip)) {
          ROS_ERROR("No value set for flip parameter");
        }

        // Flip eye if should flip
        auto all_columns_range = raw_angles_t::index_range(0, points_per_line);
        if (should_flip) {
          for (unsigned int top_row_index = 0, bottom_row_index = num_lines - 1;
               top_row_index < num_lines / 2;
               top_row_index++, bottom_row_index--) {

            auto top_el_view = elevations_msg[ boost::indices[top_row_index][all_columns_range] ];
            auto bottom_el_view = elevations_msg[ boost::indices[bottom_row_index][all_columns_range] ];
            auto top_az_view = azimuths_msg[ boost::indices[top_row_index][all_columns_range] ];
            auto bottom_az_view = azimuths_msg[ boost::indices[bottom_row_index][all_columns_range] ];

            for (unsigned int idx = 0; idx < points_per_line; idx++) {
              std::swap(top_el_view[idx], bottom_el_view[idx]);
              std::swap(top_az_view[idx], bottom_az_view[idx]);
            }

            for (std::size_t return_index = 0; return_index < num_returns; return_index++) {
              for (unsigned int edge_index = 0; edge_index < NUM_EDGES; edge_index++) {
                auto top_ret_view = returns_msg[
                  boost::indices[top_row_index][all_columns_range]
                                [return_index][edge_index]];
                auto bottom_ret_view = returns_msg[
                  boost::indices[bottom_row_index][all_columns_range]
                                [return_index][edge_index]];
                for (unsigned int idx = 0; idx < points_per_line; idx++) {
                  std::swap(top_ret_view[idx], bottom_ret_view[idx]);
                }
              }
            }
          }
        }

        // Re-order points correctly, reverse odd rows
        for (unsigned int row_index = 0; row_index < num_lines; row_index += 2) {
          auto el_view = elevations_msg[ boost::indices[row_index][all_columns_range] ];
          std::reverse(el_view.begin(), el_view.end());

          auto az_view = azimuths_msg[ boost::indices[row_index][all_columns_range] ];
          std::reverse(az_view.begin(), az_view.end());

          for (std::size_t return_index = 0; return_index < num_returns; return_index++) {
            for (unsigned int edge_index = 0; edge_index < NUM_EDGES; edge_index++) {
              auto ret_view = returns_msg[
                boost::indices[row_index][all_columns_range]
                              [return_index][edge_index]];
              std::reverse(ret_view.begin(), ret_view.end());
            }
          }
        }

        // Publish the eye
        if (eye == LUM_GREEN_EYE) {
          pub_raw_green.publish(eye_data_msg);
        } else {
          pub_raw_blue.publish(eye_data_msg);
        }
      }
      ++count;
    });

    publisher_thread.detach();
    return false;
  };

  // Set up FPGA client
  unsigned int heartbeat_period_ms = 100;

  // Publish all returns.
  std::vector<uint8_t> cli_return_indices = {0, 1, 2, 3, 4, 5, 6};

  FpgaClient3 client(LUM_LIDAR_PORT, fpga_ip_address, callback, heartbeat_period_ms,
                     1000, 64, cli_return_indices);

  using uint8_callback_t = const boost::shared_ptr<const std_msgs::UInt8>;

  // Callback for number of returns change
  boost::function<void(uint8_callback_t&)> number_of_returns_changed = [&](uint8_callback_t& msg) {
  uint8_t val = msg->data;
    if (val < 8) {
      if (val != client.num_returns() - 1) {
        std::vector<uint8_t> new_return_indices;
        for (uint8_t i = 0; i < val; ++i) { new_return_indices.push_back(i); }
        client.set_return_indices(new_return_indices);
      }
    }
  };

  // Subscribe to number of returns change
  ros::Subscriber sub_num_returns =
    nh.subscribe<std_msgs::UInt8>("/luminar_num_returns", 2, number_of_returns_changed);

  std::thread ros_thread([] { ros::spin(); });

  // Start FPGA client
  client.start();
}
