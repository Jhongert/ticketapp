//
//
// point_types.hpp
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#ifndef LUM_POINT_TYPES_HPP_
#define LUM_POINT_TYPES_HPP_

#include <boost/multi_array.hpp>

namespace lum {

  enum class EventEdge : uint8_t {
    /** Rising edge of return pulse */ Rising = 0,
    /** Falling edge of return pulse */ Falling = 1
  };

  /**
    * Data structure for holding raw returns.
    * Buffer of size height x width x return x edge
    */
  using raw_returns_t = boost::multi_array<float, 4>;

  /**
    * Data structure for holding raw angles.
    * Buffer of size height x width
    */
  using raw_angles_t  = boost::multi_array<int16_t, 2>;

  /**
    * Data structure for holding a point in cartesian coordinates
    */
  struct PointXYZ {
    float x, y, z;
  };

}

#endif // LUM_POINT_TYPES_HPP_
