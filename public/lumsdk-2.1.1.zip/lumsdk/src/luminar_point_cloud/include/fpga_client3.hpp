//
//
// fpga_client3.hpp
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#ifndef __FPGA_CLIENT3_HPP__
#define __FPGA_CLIENT3_HPP__

#include <boost/bind.hpp>
#include <boost/asio.hpp>
#include <boost/multi_array.hpp>

#include <iostream>
#include <fstream>
#include <mutex>
#include <stdint.h>
#include <sys/types.h>
#include <sys/socket.h>

#include <unordered_map>

#include "lum_packet_format.h"
#include "point_types.hpp"

using boost::asio::ip::udp;

namespace lum {

  /**
    * Type of callback to accept raw data from FpgaClient3
    */
  using frame_complete_callback_t =
    std::function<bool(
      const std::unordered_map<lum_eye_t, raw_returns_t>&,
      const std::unordered_map<lum_eye_t, raw_angles_t>& eye_to_azimuths,
      const std::unordered_map<lum_eye_t, raw_angles_t>& eye_to_elevations,
      const std::vector<uint8_t>& return_numbers)>;

  /**
   * Decodes the 32-bit sample values.
   * Note, these ranges are inclusive on both sides.
   * - bits 31 downto 12 are the tof distance where LSB is 13ps
   * - bit 11 is 0.
   * - bit 10 is 0.
   * - bits 9 downto 0 are the index into the scan line, between 0 and 999
   *   inclusive.
   */
  inline void unpack_sample(int32_t sample, float *tof_ret,
          uint16_t *index_in_line_ret) {
    *tof_ret = static_cast<float>(sample >> 12);
    *index_in_line_ret = sample & 0x3ff;
  }

  class FpgaClient3 {
  public:
    explicit FpgaClient3(uint16_t fpga_port,
                         boost::asio::ip::address_v4 fpga_ip_address,
                         frame_complete_callback_t callback,
                         long heartbeat_period_ms,
                         uint16_t points_per_line,
                         uint16_t num_horizontal_lines,
                         std::vector<uint8_t> return_indices);
    ~FpgaClient3();

    /** Begin receiving packets from the FPGA. A blocking call. */
    void start();

    /** Set FPGA IP address */
    void set_fpga_ip_address(const std::string&);

    /** Set number of horizontal scan lines. Expected value is 64. */
    void set_num_horizontal_lines(uint16_t);

    /** Set indices of multiple returns, e.g. we will be expecting the 0-3 return */
    void set_return_indices(std::vector<uint8_t>);
    inline std::size_t num_returns() const { return return_indices_.size(); }

    /** Rising and falling edge per return */
    static constexpr std::size_t NUM_EDGES_PER_RETURN = 2;

    /** Max 8 returns from the fpga */
    static constexpr std::size_t MAX_NUM_RETURNS = 8;

    /**
      * Almost the minimum float32 value. I don't expect us to ever get
      * a value like this, given our timing.
      */
    static constexpr float MISSING_RETURN = -3.4e+38;


  private:
    void send_heartbeat_packet();
    void setup_receive();
    void handle_receive_from(const boost::system::error_code& error,
                             std::size_t bytes_recvd);


    long heartbeat_period_ms_;
    boost::asio::io_service io_service_;
    boost::asio::deadline_timer heartbeat_timer_;
    udp::socket socket_;
    // The FPGA is a server. We have to inititiate communication with
    // it, so we are its client.
    udp::endpoint fpga_endpoint_;
    udp::endpoint receive_endpoint_;

    // vector of return indices, with values 0-8
    std::vector<uint8_t> return_indices_;

    // Need to index via nth return.
    std::unordered_map<lum_eye_t, raw_returns_t> eye_to_returns_;
    std::unordered_map<lum_eye_t, raw_angles_t> eye_to_azimuths_;
    std::unordered_map<lum_eye_t, raw_angles_t> eye_to_elevations_;
    uint16_t points_per_line_;
    uint16_t num_horizontal_lines_;
    uint16_t num_returns_;
    frame_complete_callback_t callback_;

    bool
      have_last_blue_tof_packet_,
      have_last_blue_angle_packet_,
      have_last_green_tof_packet_,
      have_last_green_angle_packet_;

    lum_group_packet *current_packet_;

    uint16_t current_line_;
    uint32_t last_timestamp_;

    std::mutex mutex_;
  };
}

#endif // __FPGA_CLIENT3_HPP__
