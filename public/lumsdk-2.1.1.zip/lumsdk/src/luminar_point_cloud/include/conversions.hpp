//
//
// conversions.hpp
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#ifndef LUM_CONVERSIONS_HPP_
#define LUM_CONVERSIONS_HPP_

#include "point_types.hpp"

namespace lum {

  /**
   * Converts a point from spherical to cartesian coordinates.
   * Implements this: http://mathworld.wolfram.com/SphericalCoordinates.html
   */
  lum::PointXYZ spherical(float azimuth_degrees, float elevation_degrees,
                          float depth);

  /**
   * Undiscretizes a raw range value from the FPGA,
   * subject to calibration parameters.
   */
  float meter_of_disc_distance(const float disc_distance,
                               const float distance_offset);

  /**
   * Undiscretizes a raw azimuth value from the FPGA,
   * subject to calibration parameters.
   */
  float azimuth_deg_of_disc_azimuth(const float disc_angle,
                                    const float azimuth_fov,
                                    const float azimuth_disc_min,
                                    const float azimuth_disc_max);

  /**
   * Undiscretizes a raw elevation value from the FPGA,
   * subject to calibration parameters.
   */
  float elevation_deg_of_disc_elevation(const float disc_angle,
                                        const float elevation_min,
                                        const float elevation_max,
                                        const float elevation_disc_min,
                                        const float elevation_disc_max);
} // namespace lum
#endif // LUM_CONVERSIONS_HPP_
