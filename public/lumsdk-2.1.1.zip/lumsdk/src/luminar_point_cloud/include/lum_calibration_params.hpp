//
//
// lum_calibration_params.hpp
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#ifndef _LUM_CALIBRATION_PARAMS_HPP_
#define _LUM_CALIBRATION_PARAMS_HPP_

namespace lum {

 /** phase shift (int): An additive offset to account for a lag in sampling ranges. */
const std::string GREEN_PHASE_SHIFT_PARAM = "luminar_green_phase_shift";

/** range offset (float, meters): Additive offset to measured range in meters. */
const std::string GREEN_RANGE_OFFSET_PARAM = "luminar_green_range_offset";

/**
  * highest altitude (float, degrees): Furthest angle that the green eye
  * looks upward.
  * - N.B.: The difference between highest altitude and lowest altitude
  * equals the vertical field of view.
  */
const std::string GREEN_HIGHEST_ALTITUDE_DEGREES_PARAM = "luminar_green_highest_altitude_degrees";

/** lowest altitude (float, degrees): Furthest angle that the green eye looks downward. */
const std::string GREEN_LOWEST_ALTITUDE_DEGREES_PARAM = "luminar_green_lowest_altitude_degrees";

/** elevation center (float, degrees): Physical center of the green eye scan in degrees */
const std::string GREEN_ELEVATION_CENTER_DEGREES = "luminar_green_elevation_center_degrees";

/**
  * azimuth center (float, degrees): The middle of the field of view of
  * the eye in terms of azimuth (counterclockwise degrees from the x
  * axis). The 500th point of a horizontal scan is at the azimuth
  * center.
  */
const std::string GREEN_AZIMUTH_CENTER_DEGREES_PARAM = "luminar_green_azimuth_center_degrees";

/**
  * azimuth width (float, degrees): The horizontal field of view of the
  * eye. This will either be 60 degrees or very close to it.
  */
const std::string GREEN_AZIMUTH_WIDTH_DEGREES_PARAM = "luminar_green_azimuth_width_degrees";

/**
  * flip: Flips the scan upside down relative to the way it was given
  * from the LIDAR.
  */
const std::string GREEN_FLIP_PARAM = "luminar_green_flip";

/**
  * sensor threshold (unsigned int, no unit): Controls sensititivity of the
  * LIDAR. Higher reduces the number of false returns, but reduces range.
  */
const std::string GREEN_SENSOR_THRESHOLD_PARAM = "luminar_green_sensor_threshold";

/**
  * galvo offset/adc offset (unsigned int, no unit): Offset
  * for precise galvo alignment.
  */
const std::string GREEN_GALVO_OFFSET_PARAM = "luminar_green_galvo_offset";

/**
  * phase shift (int): An additive offset to account for a lag in sampling ranges.
  */
const std::string BLUE_PHASE_SHIFT_PARAM = "luminar_blue_phase_shift";

/** range offset (float, meters): Additive offset to measured range in meters. */
const std::string BLUE_RANGE_OFFSET_PARAM = "luminar_blue_range_offset";

/**
  * highest altitude (float, degrees): Furthest angle that the blue eye
  * looks upward.
  * - N.B.: The difference between highest altitude and lowest altitude
  * equals the vertical field of view.
  */
const std::string BLUE_HIGHEST_ALTITUDE_DEGREES_PARAM = "luminar_blue_highest_altitude_degrees";

/** lowest altitude (float, degrees): Furthest angle that the blue eye looks downward. */
const std::string BLUE_LOWEST_ALTITUDE_DEGREES_PARAM = "luminar_blue_lowest_altitude_degrees";

/** elevation center (float, degrees): Physical center of the blue eye scan in degrees */
const std::string BLUE_ELEVATION_CENTER_DEGREES = "luminar_blue_elevation_center_degrees";

/**
  * azimuth center (float, degrees): The middle of the field of view of
  * the eye in terms of azimuth (counterclockwise degrees from the x
  * axis). The 500th point of a horizontal scan is at the azimuth
  * center.
  */
const std::string BLUE_AZIMUTH_CENTER_DEGREES_PARAM = "luminar_blue_azimuth_center_degrees";

/**
  * azimuth width (float, degrees): The horizontal field of view of the
  * eye. This will either be 60 degrees or very close to it.
  */
const std::string BLUE_AZIMUTH_WIDTH_DEGREES_PARAM = "luminar_blue_azimuth_width_degrees";

/**
  * flip: Flips the scan upside down relative to the way it was given
  * from the LIDAR.
  */
const std::string BLUE_FLIP_PARAM = "luminar_blue_flip";

/**
  * sensor threshold (unsigned int, no unit): Controls sensititivity of the
  * LIDAR. Higher reduces the number of false returns, but reduces range.
  */
const std::string BLUE_SENSOR_THRESHOLD_PARAM = "luminar_blue_sensor_threshold";

/**
  * galvo offset/adc offset (unsigned int, no unit): Offset
  * for precise galvo alignment.
  */
const std::string BLUE_GALVO_OFFSET_PARAM = "luminar_blue_galvo_offset";

/**
  * laser power (unsigned int, no unit): Controls power of laser. Higher power
  * means increased range. 0 to 100.
  */
const std::string LASER_POWER_PARAM = "luminar_laser_power";

/** horizon angle (float, degrees): elevation angle of horizon depending on sensor alignment */
const std::string HORIZON_ANGLE_DEGREES = "horizon_angle_degrees";

const std::string FPGA_GREEN_DETECTOR_THRESHOLD_PARAM =
  "luminar/fpga/config/green_detector_threshold";

const std::string FPGA_GREEN_GALVO_OFFSET_PARAM =
  "luminar/fpga/config/green_galvo_offset";

const std::string FPGA_BLUE_DETECTOR_THRESHOLD_PARAM =
  "luminar/fpga/config/blue_detector_threshold";

const std::string FPGA_BLUE_GALVO_OFFSET_PARAM =
  "luminar/fpga/config/blue_galvo_offset";

const std::string FPGA_HOLDOFF_DELAY_PARAM =
  "luminar/fpga/config/holdoff_delay";

const std::string FPGA_AUTOPHASE_OVERRIDE_PARAM =
  "luminar/fpga/config/autophase_override";



}

#endif
