//
//
// lum_tlv_eth_protocol.h
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#ifndef __LUM_TLV_ETH_PROTOCOL_H__
#define __LUM_TLV_ETH_PROTOCOL_H__
/** @file */

/*
 * ---------------------------------------------------------------------------
 *  TLV structures
 * ---------------------------------------------------------------------------
 */
#include <stdint.h>

#define MAX_TLV_PAYLOAD_SIZE (1400)
#define TLV_PACKET_HEADER_SIZE offsetof(LUM_TLV_PACKET, tlvs)
#define MAX_TLV_PACKET_SIZE (TLV_PACKET_HEADER_SIZE + MAX_TLV_PAYLOAD_SIZE)

/**
 * The correct values, in order, of
 * LUM_TLV_PACKET::magic_number_shorts
 *
 * The communication between the Luminar sensor and client machine occurs over UDP.
 * UDP payloads contain a common 12 byte header at the start of the UDP payload:
 *
 * The first 8 bytes of the datagram are a unique identifier to signify that this is a Luminar packet.
 * This is a check to minimize the chances of another packet being misinterpreted, to compensate for the connectionless nature of UDP. Any packet whose first 8 bytes are not equal to LUM_MAGIC_NUMBER are ignored.
 * The next 4 bytes are for the packet type. The packet type defines how to interpret the remaining bytes of the payload.
 *
 */
#define TLV_PACKET_MAGIC_SHORT_0 (0xfeed)
#define TLV_PACKET_MAGIC_SHORT_1 (0xa1f3)
#define TLV_PACKET_MAGIC_SHORT_2 (0xbeef)
#define TLV_PACKET_MAGIC_SHORT_3 (0x1234)


typedef struct lum_tlv_packet LUM_TLV_PACKET;
/**
 * The payload of a UDP packet containing one or more TLV commands.
 * TLV stands for Type-Length-Vector, a general format where Vector is
 * the payload, Type is an identifier indicating how to interpret the
 * payload, and length is how large the payload is.
 *
 * LUM_TLV_PACKET::tlvs contains an array of LUM_TLV objects, each of
 * which represents one TLV command. The reason that it is not typed
 * as a LUM_TLV array is because LUM_TLV is a flexible struct (it
 * doesn't have a fixed size). Arrays of flexible structs are rather
 * hard for C to handle.
 *
 * Every LUM_TLV_PACKET received by the lidar will cause another
 * LUM_TLV_PACKET to be returned back to the sender, containing the
 * same LUM_TLV_PACKET::sequence number, for bookkeeping purposes.
 */
struct lum_tlv_packet {
  union {
    uint16_t magic_number_shorts[4];
    uint64_t magic_number_long;
  };
  uint32_t packet_type; /**< Must be equal to LUM_TLV_PACKET_TYPE */
  uint32_t sequence;
  char tlvs[1];
};

typedef struct lum_tlv LUM_TLV;
struct lum_tlv {
  uint16_t type;
  uint16_t length;
  char vector[1];
};

#define LUM_TLV_HEADER_SIZE offsetof(LUM_TLV, vector)

/* Bit in LUM_TLV::type indicating a response from the FPGA
 * Was (1u<<15u), but this caused "warning: large integer
 * implicitly truncated to unsigned type [-Woverflow]"
 */
#define LUM_TLV_RESPONSE_MASK (0x8000)
#define LUM_TLV_ERROR_TLV    (0xeeee)



enum {
    LUM_LASER_UNKNOWN = 0,
    LUM_LASER_DOWN,     /* Return string is ERROR */
    LUM_LASER_WARM_UP,
    LUM_LASER_READY,
    LUM_LASER_SEED_START,
    LUM_LASER_LP3_START,
    LUM_LASER_LP2_START,
    LUM_LASER_LP1_START,
    LUM_LASER_ON,
};


#define LUM_TLV_ILLEGAL_COMMAND (0)
typedef struct lum_illegal_request_payload_struct LUM_ILLEGAL_REQUEST_PAYLOAD;
/**
 *
 * Pseudo-command type that acts as a catch-all for unrecognized
 * commands. This value should never be in the LUM_TLV::type field.
 */
struct lum_illegal_request_payload_struct {
    uint32_t rc;            /**< Return error code */
    uint16_t request_type;  /**< Request type that caused the error */
    uint16_t request_len;   /**< Length of the request TLV */
};


#define LUM_TLV_LASER_POWER_TYPE (1)
typedef struct lum_tlv_laser_power_payload_struct LUM_TLV_LASER_POWER_PAYLOAD;
/**
 *
 * TLV struct for setting laser power
 */
struct lum_tlv_laser_power_payload_struct {
    uint32_t power; /**<  Laser power to set, a value between 0 and 100.*/
};

#define LUM_TLV_LASER_STATE_TYPE (2)
typedef union lum_tlv_laser_state_payload_struct LUM_TLV_LASER_STATE_PAYLOAD;
union lum_tlv_laser_state_payload_struct {
    struct
    {
        uint8_t laserState;
        uint8_t reserved1[3];
    } laser_state_struct;
    struct
    {
        uint8_t laserTestCmd;
        uint8_t testParm1;
        uint8_t testParm2;
        uint8_t testStatus;
    } laser_test_struct;
    uint32_t words32[1];
};
// valid values for LUM_TLV_LASER_STATE_PAYLOAD::laserState
enum {
    LUM_TLV_LASER_DOWN = 0,
    LUM_TLV_LASER_UP   = 1,
    LUM_TLV_LASER_SAFETY_TEST_START = 64,   /* Internal command for manufacturing test */
    LUM_TLV_LASER_SAFETY_TEST_STATUS = 65,
};

#define LUM_TLV_LASER_STATUS_TYPE (3)
typedef struct lum_tlv_laser_status_payload_struct LUM_TLV_LASER_STATUS_PAYLOAD;
struct lum_tlv_laser_status_payload_struct {
    uint32_t status;
    // TODO: We probably want to use a string field here instead of
    // exposing the 32 bit array that the laser uses.
};

// LUM_TLV_BLUE_THRESHOLD_TYPE used to be LUM_TLV_THRESHOLD_TYPE. We
// had to make the change because there used to be no way to specify
// what eye we were referring to when requesting the current threshold
// value.
#define LUM_TLV_BLUE_THRESHOLD_TYPE (4)
// Use this value so that we don't have to change the value of all of
// the following LUM_TLV_*_TYPE #define's, which would break backwards
// compatibility. I figured adding 2**14 is a reasonable thing to do
// since hopefully we won't have more than 2**14 of these TLV types.
// Note: The highest order bit (15) is reserved to indicate whether the packet came from the
// FPGA or the client.
#define LUM_TLV_GREEN_THRESHOLD_TYPE ((uint16_t)(2u<<13u) + 4u)
typedef struct lum_tlv_threshold_payload_struct LUM_TLV_THRESHOLD_PAYLOAD;
/**
 *
 * TLV struct for setting the laser threshold of an eye.
 */
struct lum_tlv_threshold_payload_struct {
    uint16_t threshold; /**< The laser threshold to set on this eye. */
    uint8_t reserved0[2];
};


#define LUM_TLV_HOLDOFF_TYPE (5)
typedef struct lum_tlv_holdoff_payload_struct LUM_TLV_HOLDOFF_PAYLOAD;
/**
 *
 * TLV struct for holdoff delay time in nanoseconds
 */
struct lum_tlv_holdoff_payload_struct {
    uint32_t holdoff; /**<  Holdoff delay time in nanoseconds. Range is from 0 ns to 255 ns */
};

// What is this type supposed to represent?
#define LUM_TLV_ERROR_TYPE (6)
typedef struct lum_tlv_error_payload_struct LUM_TLV_ERROR_PAYLOAD;
struct lum_tlv_error_payload_struct {
    uint32_t error_code;
};

#define NUM_HORIZONTAL_LINES (640)
#define LUM_TLV_YSCAN_TYPE (10)
typedef struct yscan_packet_struct YSCAN_PACKET;
/**
 *
 * === DEPRECATED ===
 *
 * TLV struct for setting yscan pattern
 */
struct yscan_packet_struct
{
    int32_t status;
    int8_t eye;
    char reserved[3];
    int16_t yscan_positions[NUM_HORIZONTAL_LINES];
};
#define YSCAN_PACKET_STATUS_GOOD (0)
#define YSCAN_PACKET_STATUS_UNSAFE_PATTERN (1)

#define YSCAN_PACKET_HEADER_SIZE (8)

#define LUM_TLV_VERSION_TYPE (11)
typedef struct version_packet_struct VERSION_PACKET;
/**
 *
 * TLV struct for getting version hash
 */
struct version_packet_struct
{
    uint32_t versionHash; /**<  Version hash of FPGA */
};

#define LUM_TLV_AUTO_PHASE_OVERRIDE_TYPE (12)

typedef struct lum_tlv_auto_phase_override_payload_struct LUM_TLV_AUTO_PHASE_OVERRIDE_PAYLOAD;
/**
 *
 * TLV struct for setting the auto phase override.
 */
struct lum_tlv_auto_phase_override_payload_struct {
    uint32_t autoPhaseOverride; /**< Whether auto calibration
                                 * procedure to set
                                 * LUM_TLV_ADC_PHASE_OFFSET_PAYLOAD#adcPhaseOffset
                                 * is on or off. 1 to turn off calibration
                                 * procedure, 0 to turn it on. It is on by default. */
};

#define LUM_TLV_SENSOR_NUMBER_RETURNS_TYPE (14)

typedef struct lum_tlv_sensor_number_returns_payload_struct LUM_TLV_SENSOR_NUMBER_RETURNS_PAYLOAD;
/**
 *
 * TLV struct for setting how many returns to receive
 */
struct lum_tlv_sensor_number_returns_payload_struct {
    uint8_t sensorNumberOfReturns;/**< Maximum number of returns to
                                   * receive. (between 1 and
                                   * 7). Normally, no more than three
                                   * returns are returned anyway. */
    uint8_t reserved0[3]; /**< Padding */
};

#define LUM_TLV_ADC_PHASE_OFFSET_BLUE_TYPE (17)
#define LUM_TLV_ADC_PHASE_OFFSET_GREEN_TYPE (18)
typedef struct lum_tlv_adc_phase_offset_payload_struct LUM_TLV_ADC_PHASE_OFFSET_PAYLOAD;
/**
 *
 * TLV struct for setting the ADC phase offset for an eye.
 */
//
struct lum_tlv_adc_phase_offset_payload_struct {
    uint32_t adcPhaseOffset;  /**< The ADC phase offset to set on this eye. */
};

#define LUM_TLV_YSCAN2_BLUE_TYPE (21)
#define LUM_TLV_YSCAN2_GREEN_TYPE (22)
typedef struct yscan2_packet_struct YSCAN2_PACKET;
/**
 *
 * TLV struct for getting yscan pattern for specified eye
 */
struct yscan2_packet_struct
{
    int32_t status;
    int16_t yscan_positions[NUM_HORIZONTAL_LINES]; /**< The positions for each horizontal scan
                                                      line in 1 Hz mode in millidegrees from
                                                      the horizon. */
};

#endif // __LUM_TLV_ETH_PROTOCOL_H__
