//
//
// lum_eth_protocol.h
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#ifndef __LUM_ETH_PROTOCOL_H__
#define __LUM_ETH_PROTOCOL_H__
/** @file */

#include "lum_tlv_eth_protocol.h"

/**
 * Define the packet types. These are the only valid values for the
 * ::packet_type fields in the struct definitions. The right value for
 * each struct's ::packet_type field is documented in-line with the
 * struct's definition. For example, ADDRESS_PACKET#packet_type
 * must equal ADDRESS_PACKET_TYPE.
 *
 * The enum below is the word immediately following the 8-byte magic
 * in the UDP data frame.  All values are assumed to be little endian.
 * Note: All datagrams must be at least 60 bytes long.
 * Max length is dependent on the current MTU of the link.
 * The FPGA does not do fragmentation.
 */
enum
{
    TEST_PATTERN_PACKET_TYPE = 0,
    REAL_DISTANCE_PACKET_TYPE = 1,
    REAL_TEST_PACKET_TYPE = 2,
    SENSOR_DATA_STOP = 3,
    UNUSED_TYPE = 4,
    ADDRESS_PACKET_TYPE = 5,
    PACKET_TIMESTAMP = 6,
    LUM_TLV_PACKET_TYPE = 7, // see lum_tlv_eth_protcol.h
    LUM_MULTI_DISTANCE_PACKET_TYPE = 8,
};




#define MAX_POINTS_PER_HORIZONTAL_LINE  (1000)

// Standins for an enum type for lum_line_payload::eye.
// We can't use an enum because we cannot specify in C that the integral type
// of the enum is uint8_t. See:
// http://stackoverflow.com/questions/4879286/specifying-size-of-enum-type-in-c
typedef uint8_t lum_eye_t;
#define EYE_GREEN (0)
#define EYE_BLUE  (1)
#define LUM_LEFT_EYE  (EYE_GREEN)
#define LUM_RIGHT_EYE (EYE_BLUE)
#define LUM_GREEN_EYE (LUM_LEFT_EYE)
#define LUM_BLUE_EYE  (LUM_RIGHT_EYE)

/*
 * Struct definition for header for image data.
 */
#define USE_LUM_REV_0_1_FORMAT  (0)
#if USE_LUM_REV_0_1_FORMAT

/*
 * Note: This format is deprecated.  DO NOT USE!!!
 * We will keep the definition here temporarily to help in understanding
 * some of the old legacy code.
 */
typedef struct {
  // 0 for left, 1 for right
  lum_eye_t  eye;
  // padding
  uint8_t  reserved;
  // vertical scan line #
  uint16_t line;
  // number of distance samples, in case of fragmentation
  uint16_t num_samples;
  // index of first sample, in case of fragmentation
  uint16_t first_sample_index;
  // Timestamp of first point in microseconds since bootup
  uint32_t first_timestamp_us;
} lum_group_header_depricated_do_not_use_under_any_circumstance;

#else

/**
 * LIDAR data is sent to the client in groups of points; there are 1000 points in a line.
 * Each line is transmitted as a group of UDP packets, the lum_group_header contains the
 * information necessary to identify a line. The lum_group_packet contains a header
 * and a payload, either angle or range data.
 *
 * Angle payloads are transmitted in groups of (334, 334, 332) samples for the rising edges of the blue and green eyes.
 * Angle are transmitted 16 bit signed fixed-point values which must be converted to degrees or radians.
 * Within the angle packet header, the values of line, num_samples, and first_sample_index allow you to index
 * an angle value within a frame.
 *
 * Ranges are transmitted as 32 bit signed integers. Along with the line and num_samples values from the header,
 * some bits of the 32 allow you to index the range data within a frame. The multi-return packet format is documented below.
 * Note: the return index is not given, to determine the index of a return within the total number of requested returns,
 * you must count up from 0th return, 1st, ...
 *
 * Multi-return packet format.
 * Data values for multi-return data are formatted as follows:
 * - b31-12  == Range time value
 * - b11     == 0
 * - b10     == Rising flag
 * - B9-0    == X position
 *
 * Data values immediately follow the header (lum_group_header).
 * There may be multiple returns for one pixel.
 * Multiple X return pixels will never cross a packet boundary.
 * All samples in a packet are contained on a single line.
 */
typedef struct
{
    uint8_t  tag;                /** 2=angle data, 3=range distance data */
    uint8_t  eye;                /** 0 for green rise, 1 for blue rise, 2 for green drop, 3 for blue drop */
    uint16_t line;               /** horizontal scan line # for first sample */
    uint16_t num_samples;        /** number of samples */
    uint16_t first_sample_index; /** index of first sample (angle data only) */
    uint32_t first_timestamp_us; /** Timestamp of first angle sample in microseconds since bootup (not for range data) */
} lum_group_header;

/** Values to be or'ed with the eye value to indicate rising or dropping values */
#define EYE_EYE_MASK    (1)
#define EYE_RISE_MASK   (2)
#define EYE_RISE_FLAG   (EYE_RISE_MASK)
#define EYE_DROP_FLAG   (0)

#define PIXEL_X_MASK    (0x3ff)

/** Tag values: */
enum { LUM_HDR_TAG_ADC = 2, LUM_HDR_TAG_RANGE = 3, };

#endif

typedef struct lum_angle_payload_struct LUM_ANGLE_PAYLOAD;
/**
 * Struct containing elevation and azimuth values for a sample.
 * Both elevation and azimuth values are 16 bit signed fixed-point values which must be converted to degrees or radians - this value is subject to calibration.
 * Typically  Y scaling is .0038 degrees per lsb.
 * Typically X scaling is .0030 degrees per lsb.
 */
struct lum_angle_payload_struct {
  int16_t elevation;
  int16_t azimuth;
};

typedef struct {
  lum_group_header hdr;
  char payload[1];
} lum_group_packet;

/**
 *  TEST_PATTERN_PACKET_TYPE:
 */
typedef struct test_pat_info_struct TEST_PAT_INFO;
struct test_pat_info_struct
{
    uint32_t    length;
    uint32_t    patStart;
    uint32_t    patInc;
    uint32_t    patMod;
};

typedef struct packet_test_pat_enable_struct PKT_TEST_PAT_ENABLE;
struct test_pat_pkt_struct
{
    uint32_t    packet_type;    /** == TEST_PATTERN_PACKET_TYPE */
    uint32_t    sample_period;  /** Period between samples in microseconds */

    TEST_PAT_INFO   blue_test_pat;
    TEST_PAT_INFO   green_test_pat;
};

/**
 *  LUM_MULTI_DISTANCE_PACKET_TYPE or REAL_DISTANCE_PACKET_TYPE:
 *
 * The heartbeat packet serves two primary purposes.
 * The first is to set the destination IP address and UDP port where the sensor will send LIDAR data packets.
 * The second is for safety - if a heartbeat packet is not received for a period of 3 seconds, the Luminar LIDAR will shut off the laser.
 * This is primarily to provide a safe shutdown in the event of malfunction.
 * It is a good idea to send a heartbeat packet several times a second to ensure the timer is not tripped.
 * This packet does not get an acknowledgement packet, but will result in LIDAR data packets being sent to the sender of the packet if successfully received.
 */
typedef struct packet_acquire_enable_struct PKT_ACQUIRE_ENABLE;
struct packet_acquire_enable_struct
{
    char    packet_type;    /** == LUM_MULTI_DISTANCE_PACKET_TYPE for multiple return or REAL_DISTANCE_PACKET_TYPE for single return. */
    char    reserved[3];
};

/**
 *  REAL_TEST_PACKET_TYPE:
 */
typedef struct packet_acquire_real_test_struct PKT_ACQUIRE_REAL_TEST;
struct packet_acquire_real_test_struct
{
    char    packet_type;    /** == REAL_TEST_PACKET_TYPE */
    char    reserved[3];
};

/**
 *  SENSOR_DATA_STOP:
 */
typedef struct packet_acquire_stop_struct PKT_ACQUIRE_STOP;
struct packet_acquire_stop_struct
{
    char    packet_type;    /** == SENSOR_DATA_STOP */
    char    reserved[3];
};

typedef struct address_packet_struct ADDRESS_PACKET;
/**
 * The Set IP Address Packet is sent by the client to the server only.
 *
 * The IP Address Packet is a non-responsive packet type.
 * The sensor will immediately try to change IP address if the packet is valid.
 * No acknowledgement packet is sent, since receiving packets from the new address should provide acknowledgement.
 * The client should then communicate with the new IP address to verify the IP address was changed.
 *
 * The client must know the server’s initial IP address in order to set its IP address.
 * Because the sensor always boots up with 10.42.0.37 as its default IP address, a packet can be directly sent to the default IP address.
 * Setting the IP address via UDP broadcast packets is not supported at this time.
 * This can be maneuvered around via Linux’s virtual network interfaces, in case your network is not a 10.x.x.x subnet.
 *
 */
struct address_packet_struct
{
    char    packetType;   /** == ADDRESS_PACKET_TYPE */
    char    reserved[3];
    uint32_t newIPAddress;
};

typedef struct timestamp_packet_struct TIMESTAMP_PACKET;
/**
 * The Timestamp Packets are sent by both the client and the lidar.
 *
 * The timestamp packet is to allow the client to know the difference between the sensor’s clock and the client’s clock.
 * When a client sends a Timestamp Pack packet to the LIDAR, the value of the sent timestamp field is ignored.
 * The response packet has the same sequence number as the request packet, but with the timestamp field set to a 32-bit timestamp since bootup when the packet entered the server’s receive queue.
 * Note that since this value is a 32 bit unsigned integer, it will reset to zero about every 71 minutes.
 * The purpose of the sequence number is to account for possible reordering of UDP packets.
 */
struct timestamp_packet_struct
{
    char    packetType; /** == PACKET_TIMESTAMP */
    char    reserved1[3];
    uint32_t sequenceNum;
    uint32_t timeStamp; /** In microseconds */
};

#endif // __LUM_ETH_PROTOCOL_H__
