//
//
// ydac_scan.h
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#ifndef __YDAC_SCAN_H__
#define __YDAC_SCAN_H__

#define NUM_Y_STEPS (640)
// DEFAULT macros correspond to our initial scan pattern: -7.5 to 7.5 degrees.
#define YMIN_DEFAULT_V (-0x2000)
#define YMIN_DEFAULT_MILLIDEGREES (-7500)
#define YSTEP_DEFAULT_V (26)
// YMAX_DEFAULT_V is a tiny bit over 0x2000, the ideal value
// corresponding to 7.5 degrees. If we use a YSTEP_DEFAULT_V value of
// (25), the value is below 0x2000, but by a greater absolute quantity
// than with a YSTEP_DEFAULT_V value of (26).
#define YMAX_DEFAULT_V (YMIN_DEFAULT_V + YSTEP_DEFAULT_V * NUM_Y_STEPS)
#define YMAX_DEFAULT_MILLIDEGREES (7500)

#define YMIN_MILLIDEGREES (-15000) // minimum y angle in millidegrees.
#define YMIN_V            (-0x4000)

#define YMAX_MILLIDEGREES (15000) // maximum y angle in millidegrees.
#define YMAX_V            (0x4000)

#define YMIDDLE_V         ((YMAX_V + YMIN_V) / 2)
#define YMIDDLE_MILLIDEGREES ((YMAX_MILLIDEGREES + YMIN_MILLIDEGREES) / 2)

#define MILLIDEGREES(x) (1000 * (x))
// Explanation: Philip's model predicts that 9.5 lines spanning just 1
// degree is bad in 10 Hz mode. Make this 10 lines as a fudge
// factor. In 1 Hz mode, we are scanning the same area  only a 10th as much.
#define MIN_SAFE_STEP_SIZE  (((MILLIDEGREES(1) * 17) / 100) / 10)

void yScanInit(uint8_t eye, int16_t yMinV, int16_t yStepV);
void yScanRead(uint8_t eye);
void processYscan(const int16_t* yScanPositions, int32_t* status, uint8_t eye);

#endif // __YDAC_SCAN_H__
