//
//
// lum_packet_format.h
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#ifndef LUM_PACKET_FORMAT_H_
#define LUM_PACKET_FORMAT_H_

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include "fpga-firmware/sw/lum_eth_protocol.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef uint8_t lum_device_rate_t;

// No padding of the packet
#pragma pack(push, 1)

/** The default port of the Lidar at startup */
const uint16_t LUM_LIDAR_PORT = 5117;

/** The default IP of the Lidar at startup */
const uint32_t LUM_LIDAR_IP_ADDRESS = 10 << 24 | 42 << 16 | 0 << 8 | 37;

/** The default IP of the Lidar at startup */
const char* const LUM_LIDAR_IP_ADDRESS_STR = "10.42.0.37";

/* Values to be or'ed with the eye value to indicate rising or dropping values */
#define EYE_EYE_MASK    (1)
#define EYE_BLUE_FLAG   (EYE_EYE_MASK)
#define EYE_GREEN_FLAG  (0)

#define EYE_RISE_MASK   (2)
#define EYE_RISE_FLAG   (EYE_RISE_MASK)
#define EYE_DROP_FLAG   (0)

#define LUM_EYE_GREEN_RISE ( EYE_RISE_FLAG | EYE_GREEN_FLAG)
#define LUM_EYE_BLUE_RISE ( EYE_RISE_FLAG | EYE_BLUE_FLAG)
#define LUM_EYE_GREEN_DROP ( EYE_DROP_FLAG | EYE_GREEN_FLAG)
#define LUM_EYE_BLUE_DROP ( EYE_DROP_FLAG | EYE_BLUE_FLAG)

#define LUM_TOF_HEADER_SIZE_BYTES (offsetof(lum_group_packet, payload))
#define LUM_TOF_MAX_NUM_SAMPLES (350)
#define LUM_TOF_MAX_SIZE_BYTES (LUM_TOF_HEADER_SIZE_BYTES + \
                                LUM_TOF_MAX_NUM_SAMPLES * sizeof(float))

#define LUM_ANGLE_HEADER_SIZE_BYTES (offsetof(lum_group_packet, payload))
#define LUM_ANGLE_MAX_NUM_SAMPLES (350)
#define LUM_ANGLE_MAX_SIZE_BYTES (LUM_ANGLE_HEADER_SIZE_BYTES + \
                                  LUM_ANGLE_MAX_NUM_SAMPLES * sizeof(LUM_ANGLE_PAYLOAD))

#pragma pack(pop)

#define LUM_GROUP_HEADER_SIZE (offsetof(lum_group_packet, payload))
#define LUM_GROUP_MAX_SIZE    (LUM_ANGLE_MAX_SIZE_BYTES)
#define LUM_MAX_POINTS_PER_GROUP (350)
#define LUM_ANGLE_DATA_SIZE (sizeof(LUM_ANGLE_PAYLOAD))

// The size in bytes of a lum_group_packet including the array of
// angle values and the array of distance values
size_t lum_group_packet_size(const lum_group_packet*);
#define LUM_RANGE_GROUP_MAX_SIZE lum_group_packet_size(LUM_HDR_TAG_RANGE)
#define LUM_ANGLE_GROUP_MAX_SIZE lum_group_packet_size(LUM_HDR_TAG_ADC)

#pragma pack(push, 1)

typedef struct {
  union {
    uint16_t magic_number_shorts[4];
    uint64_t magic_number_long;
  };
  uint8_t packet_type;
  uint8_t reserved0[3];
} lum_heartbeat_packet;

#define LUM_MAGIC_NUMBER (0x1234L << 48 | 0xbeefL << 32 | 0xa1f3L << 16 | 0xfeedL)

lum_heartbeat_packet lum_multi_return_heartbeat_packet();

typedef struct {
  union {
    uint16_t magic_number_shorts[4];
    uint64_t magic_number_long;
  };
  uint8_t packet_type;
  uint8_t reserved0[3];
  uint32_t sequence;

  uint32_t timestamp;

} lum_timestamp_packet;

lum_timestamp_packet lum_make_timestamp_packet(uint32_t sequence);
bool lum_timestamp_send_and_receive(uint32_t lidar_ip_address, uint32_t sequence,
                                    uint32_t *received_timestamp);

typedef struct lum_address_packet_struct LUM_ADDRESS_PACKET;
struct lum_address_packet_struct
{
  union {
    uint16_t magic_number_shorts[4];
    uint64_t magic_number_long;
  };
  char    packet_type;   /* == LUM_ADDRESS_PACKET_TYPE */
  char    reserved[3];
  uint32_t new_ip_address;
};

LUM_ADDRESS_PACKET lum_make_address_packet(uint32_t new_ip_address);
void lum_transmit_address_packet(LUM_ADDRESS_PACKET packet,
                                 uint32_t lidar_ip_address);
void lum_broadcast_address_packet(LUM_ADDRESS_PACKET packet);

#pragma pack(pop)

#ifdef __cplusplus
}
#endif

#endif
