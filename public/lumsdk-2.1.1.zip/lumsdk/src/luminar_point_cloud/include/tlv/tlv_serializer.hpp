//
//
// tlv_serializer.hpp
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#ifndef _TLV_SERIALIZER_HPP_
#define _TLV_SERIALIZER_HPP_

#include <vector>
#include <atomic>

#include <boost/bind.hpp>

#include "fpga-firmware/sw/lum_eth_protocol.h"

namespace lum {

  class TLVSerializer {
  public:
    TLVSerializer();

    ///
    /// Returns -1 if operation fails. Otherwise, it returns the size in
    /// bytes of the p_tlv_packet->tlvs field
    ///
    int fill_tlv_packet_from_vec(const std::vector<const LUM_TLV*>& tlv_vec,
                                 uint32_t sequence, LUM_TLV_PACKET* p_tlv_packet) const;

    ///
    /// Caller is responsible for calling 'free_tlv_vec'' when done using the vector of TLVs since each TLV is dynamically allocated.
    ///
    /// tlvs_field_length: length of the LUM_TLV_PACKET::tlvs field in
    /// tlv_packet
    ///
    /// TODO: make a for_each method that takes an action func that operates on each LUM_TLV so no dynamic memory is needed
    ///
    std::vector<const LUM_TLV*> allocate_tlv_vec_from_packet(const LUM_TLV_PACKET* tlv_packet,
                                                             std::size_t tlvs_field_length) const;

    ///
    /// Frees previously allocated TLVs from 'allocate_tlv_vec_from_packet'.
    /// Vector should be cleared afterwards as to not by mistake use deinitialized memory.
    ///
    void free_tlv_vec(const std::vector<const LUM_TLV*>& tlv_vec) const;

    uint32_t get_sequence() { return sequence_; }
    uint32_t get_post_increment_sequence() { return sequence_++; }

  private:

    ///
    /// Caller is responsible for freeing TLV because this method dynamically allocates a copy of the TLV from the source buffer
    ///
    const LUM_TLV* allocate_tlv_from_packet_buffer(const LUM_TLV& tlv_from_buffer) const;

    std::atomic<uint32_t> sequence_;
  };

}

#endif // _TLV_SERIALIZER_HPP_
