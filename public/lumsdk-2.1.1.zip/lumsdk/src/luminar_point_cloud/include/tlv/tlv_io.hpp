//
//
// tlv_io.hpp
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#ifndef _TLV_IO_HPP_
#define _TLV_IO_HPP_

#include <map>
#include <boost/bind.hpp>
#include <boost/asio.hpp>
#include <thread>
#include <functional>

#include "fpga-firmware/sw/lum_eth_protocol.h"

namespace lum {

  class TLVIO {
  public:

    ///
    /// Constructor to communicate with FPGA
    /// @param receive_tlv_packet_func: Returns whether
    ///
    TLVIO(const boost::asio::ip::udp::endpoint& dest_endpoint,
          std::function<bool(TLVIO&, const LUM_TLV_PACKET*, std::size_t)> receive_tlv_packet_func,
          long resend_period_sec = 0L);

    ///
    /// Constructor to communicate using test client and server
    ///
    TLVIO(const boost::asio::ip::udp::endpoint& dest_endpoint,
          uint16_t src_port,
          std::function<bool(TLVIO&, const LUM_TLV_PACKET*, std::size_t)> receive_tlv_packet_func,
          long resend_period_sec = 0L);

    ~TLVIO();

    void run();
    void stop();
    /**
     * It is the caller's responsibility to deallocate tlv_packet after
     * calling this method
     *
     * The send() does not need to be acknowledged before it is safe to
     * deallocate tlv_packet
     */
    void send(const LUM_TLV_PACKET* tlv_packet, std::size_t tlvs_field_length);

  private:
    void setup_socket_to_receive();
    void handle_receive_from(const boost::system::error_code& error,
                             std::size_t bytes_recvd);
    void on_resend_packet_timer_tick(const boost::system::error_code& e,
                                     boost::asio::deadline_timer* t,
                                     int* count);
    bool should_resend_unacknowledged_packets() const { return resend_timer_period_sec_ != 0L; }
    void resend_unacknowledged_packets();

    std::map<uint32_t, std::pair<LUM_TLV_PACKET*, std::size_t>> sent_tlv_packets_;

    LUM_TLV_PACKET *received_tlv_packet_;

    boost::asio::io_service io_service_;
    boost::asio::ip::udp::socket socket_;
    boost::asio::ip::udp::endpoint dest_endpoint_;
    long resend_timer_period_sec_;
    boost::asio::deadline_timer resend_packet_timer_;
    boost::asio::ip::udp::endpoint received_from_endpoint_;
    std::function<bool(TLVIO&, const LUM_TLV_PACKET*, std::size_t)> receive_tlv_packet_func_;

  };

}

#endif // _TLV_IO_HPP_
