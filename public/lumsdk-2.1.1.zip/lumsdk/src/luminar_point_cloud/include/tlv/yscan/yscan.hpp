//
//
// yscan.hpp
//
// Copyright (c) 2017, Luminar Technologies, Inc.
//
// This material contains confidential and trade secret information of Luminar Technologies.
// Reproduction, adaptation, and distribution are prohibited, except to the extent expressly permitted in
// writing by Luminar Technologies.
//

#ifndef __YSCAN_HPP__
#define __YSCAN_HPP__

// Include FPGA file for all constants, etc
#include "fpga-firmware/sw/ydac_scan.h"

namespace lum {

  /**
   * Interpolate between two values with a given alpha.
   */
  float interpolate(float x, float y, float alpha);

  /**
   * Generate a uniform scan pattern between the min and max millidegrees
   * @pre min_millidegrees cannot be less than YMIN_MILLIDEGREES
   * @pre max_millidegrees cannot be greater than YMAX_MILLIDEGREES
   */
  std::array<int16_t, NUM_Y_STEPS> uniform_scan(float min_millidegrees,
                                                float max_millidegrees);

  /**
   * Checks whether a given array of yscan angles is eye safe, i.e.
   * the minimum angular distance between lines is greater than
   * required for all lines.
   */
  bool scan_pattern_eye_safe(const std::array<int16_t, NUM_Y_STEPS>& pattern);

}

#endif // __YSCAN_HPP__
